# Centralised Info — Workflow

## Entrypoint

`app.py` — a Flask app run with:

```
.venv\Scripts\python app.py
```

It serves the UI at `http://127.0.0.1:5050` and exposes a small JSON API the
frontend (`static/js/app.js`) calls with `fetch`. Frontend and API are served
from the same Flask process/origin, so there is no CORS to configure.

## Files

| File | Responsibility |
|---|---|
| `app.py` | Flask routes only — request/response glue, no Mongo/crypto logic |
| `config_store.py` | Encrypt/save/load/clear the Mongo connection string locally |
| `db_service.py` | All MongoDB queries and the persona branching logic |
| `templates/index.html` | Page structure: top bar, search box, 3 cards, assignments list, config modal |
| `static/css/styles.css` | Visual design (shadcn-inspired: neutral palette, rounded cards, subtle motion, dark-mode aware) |
| `static/js/app.js` | All client behavior: connection status polling, search, in-memory history, rendering |

## Input

1. **Mongo connection string** — entered once via the connection indicator (top-right) → modal → "Test & Save". Never typed twice; never stored in an env var or inside the project folder.
2. **Email address** — typed into the search box, submitted with Enter.

## Process

### 1. Connecting

- `POST /api/config` receives `{ uri }`.
- `db_service.test_connection(uri)` opens a `MongoClient` and runs `admin.command("ping")`. If it fails, the error is shown in the modal and nothing is saved.
- On success, `config_store.save_uri(uri)` encrypts the string with `cryptography.Fernet` using a key derived from this Windows machine's `MachineGuid` (`SOFTWARE\Microsoft\Cryptography` in the registry) and writes the ciphertext to `%APPDATA%\CentralisedInfo\config.enc`.
- Because the key is derived from the machine itself, the file is only decryptable on this PC — copying it elsewhere is useless, without needing any password/passphrase from the user.
- On every page load, `GET /api/config/status` loads + decrypts the saved URI (if any) and re-pings Mongo, driving the green/red dot.

### 2. Looking up an email

`GET /api/lookup?email=...` → `db_service.lookup_email(email)`:

1. **`Rubix.profile_associations`** — case-insensitive exact match on `email` (regex `^email$` with `i` option). This document carries:
   - `persona` — `"Student"`, `"School"`, or `"Site"`
   - `oneProfileId` — ObjectId → name lookup
   - `active` — whether this user/association itself is active (shown as **User Active/Inactive** badge on the Profile card)
   - `oneSchoolId` (only meaningful when persona is `School`)
   - `tenantId` (only meaningful when persona is `Site`)

2. **`ExxatNetwork.master_profiles`** — fetched by `_id = oneProfileId` regardless of persona, giving `firstName`/`lastName` for the Profile card.

3. **Persona-specific branch:**

   - **Student** → query `Rubix.assignees` by the same case-insensitive email to get `_id`, `oneSchoolId`, `tenantId`:
     - `Rubix.tenant_schools` by `_id = oneSchoolId` → school `name`, `active`, and POC contacts (flattened from `addresses[].contacts[]`).
     - `Rubix.tenant_sites` by `_id = tenantId` → site `name`, `active`, and POC contacts (same shape).
     - `Rubix.assignments` with `{ assigneeId: assignees._id }` — can return multiple documents, each rendered as its own card:
       - `policy.stdCanViewAsnm` → **Student Confirmed** badge
       - `subscription.payStatus === "Paid"` → **Payment Done** badge (otherwise shows the raw status)
       - `availabilities[]` → chips, struck through when `active` is false
       - `startDate` / `endDate` → formatted `dd/mm/yyyy`
       - `onb.compliant` → **Onboarding Compliant/Not Compliant**
       - `ofb.compliant` → **Offboarding Compliant/Not Compliant**
       - `caas.compliant` → **CAAS Compliant/Not Compliant**

   - **School** → `oneSchoolId` is read directly off the `profile_associations` document (no `assignees` hop) and used as `_id` into `Rubix.tenant_schools`, giving school `name`, `active`, and POC contacts. No Site card or assignments for this persona.

   - **Site** → `tenantId` is read directly off the `profile_associations` document and used as `_id` into `Rubix.tenant_sites`, giving site `name`, `active`, and POC contacts. No School card or assignments for this persona.

4. The assembled result is returned as one JSON payload and rendered into the 3 cards (Profile / School / Site) plus an Assignments section (students only).

## Logic notes / conventions

- **"Active" always means the same thing**: a boolean `active` field on the source document, shown as a green ("...Active") or red ("...Inactive") badge. It appears in three places with three different meanings — user/association active (Profile card), school active (School card), site active (Site card) — but the rendering code (`renderOrgCard` / the user badge in `renderResult`) is shared.
- **Case-insensitivity** is implemented as a regex (`^email$`, option `i`) rather than lower-casing in the app, so it works regardless of how the email was cased when stored.
- **Search history** is kept only in the browser's JS memory (`state.history` in `app.js`) — it is never written to disk, and clicking a history chip re-renders from the cached result instead of re-querying Mongo. It disappears when the app/browser tab is closed, as requested.
- **No app-level encryption of query results** — only the connection string is encrypted at rest; profile/school/site data is only ever held in memory (server request scope + browser JS state).

## Known open assumption

- The exact field name for email in `profile_associations` and `assignees` is assumed to be `email` in both collections. If either collection uses a different field name (e.g. `userEmail`), update `_email_filter` usage sites in `db_service.py` accordingly — currently both use the same helper.
