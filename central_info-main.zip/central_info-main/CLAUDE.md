# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

"Centralised Info" — a local Flask desktop-style tool (packaged as a Windows EXE via PyInstaller) that lets support/ops staff look up a user's persona (Student/School/Site), profile, school/site org info, and assignment compliance status by email, directly against production MongoDB (`ExxatNetwork` and `Rubix` databases). Single user, runs on `127.0.0.1:5050`, opens a browser tab automatically.

## Commands

Run the app (from a venv with `requirements.txt` installed):

```
.venv\Scripts\python app.py
```

There is no test suite, linter, or build script configured. To rebuild the packaged EXE, PyInstaller is driven by `CentralisedInfo.spec` (`datas` bundles `templates/` and `static/`); the `build/` directory holds prior build artifacts and can be ignored.

## Architecture

Strict separation enforced across three files — keep it that way when adding routes/logic:

| File | Responsibility |
|---|---|
| `app.py` | Flask routes only — request/response glue, no Mongo/crypto logic |
| `config_store.py` | Encrypt/save/load/clear the Mongo connection string locally |
| `db_service.py` | All MongoDB queries and the persona branching/resolution logic |
| `templates/index.html` | Page structure: top bar, search box, 3 cards, assignments list, config modal |
| `static/css/styles.css` | Visual design (shadcn-inspired, dark-mode aware) |
| `static/js/app.js` | All client behavior: connection status polling, search, in-memory history, rendering |

Frontend and API share one origin (Flask serves both), so there's no CORS layer.

### Connection string handling

- Entered once via the top-right connection indicator → modal → "Test & Save" (`POST /api/config`), which round-trips through `db_service.test_connection` (opens a `MongoClient`, runs `admin.command("ping")`) before saving anything.
- `config_store.save_uri` encrypts with `cryptography.Fernet` using a key derived from this Windows machine's `MachineGuid` (read from `SOFTWARE\Microsoft\Cryptography` in the registry), writing ciphertext to `.config.enc` next to the app (or `%APPDATA%` for the frozen EXE). The file is only decryptable on the machine that created it.
- `config_store.load_uri` also accepts `MONGODB_URI`/`MONGO_URI` from the environment or a local `.env` on first run and persists it via `save_uri`.
- `db_service.get_client()` lazily connects/reconnects using the stored URI and pings on every reuse to detect dropped connections; `app.py`'s `/api/lookup` retries up to 3 times with backoff on `PyMongoError` (Atlas connection resets over VPN are common and expected, not a bug).

### Persona resolution (`db_service._assemble_from_association`)

The core logic. Given a `Rubix.profile_associations` (actually stored in `ExxatNetwork`) document, branches on `persona`:

- **`individual`** — circuit breaker: returns master profile only, no further queries.
- **`student`** — `Rubix.assignees` (compound index `oneSchoolId + userEmail`) → `Rubix.tenant_schools` + `Rubix.tenant_sites` → batched `Rubix.assignments` query (by `assigneeId` list). Each assignment renders compliance badges (`onb`/`ofb`/`caas` compliant, `stdCanViewAsnm` → Student Confirmed, `subscription.payStatus === "Paid"` → Payment Done — strict equality, logged verbosely when it doesn't match to catch casing/whitespace artifacts in the data).
- **`school`** / **`school faculty`** — resolves `tenant_schools` directly from `tenantId`/`oneSchoolId` on the association; also pulls partner clinical sites via `Rubix.partners`.
- **`site`** — resolves `Rubix.profiles` (name + admin role flags) then `tenant_sites`; also pulls partner schools via `Rubix.partners`.

`lookup_email` fetches **all** matching `profile_associations` documents for an email (not just the first) and resolves each — a user can hold multiple personas. It flags a conflict when more than one *active Student* association exists for the same email (students should have exactly one active school). The top-level response also mirrors association `[0]`'s fields for backward compatibility with older frontend code expecting a single-persona shape.

- Email matching is always a case-insensitive regex (`^email$`, `i` option) against the `userEmail` field, never a lowercased equality check — see `_find_all_by_email` / `EMAIL_FIELD_NAME`.
- `@exxat.com` emails are refused everywhere (search input, contact lists, association filtering) — internal accounts are out of scope by policy, not a bug to "fix."
- `"active"` is a shared, three-place concept (user/association, school, site) with one shared rendering path — don't special-case it per card.
- No lookup results are ever persisted: search history lives only in browser JS memory (`state.history` in `app.js`) and is gone on tab close. Only the Mongo URI is encrypted/stored on disk.

Required MongoDB indexes for all query paths are documented in `INDEX_USED.md` (with ready-to-run `mongosh`/PyMongo setup scripts) — check it before adding a new query shape, and update it if you add one.

### Known open assumption

The email field name in `profile_associations`/`assignees` is assumed to be `userEmail` everywhere (`db_service.EMAIL_FIELD_NAME`). If a collection uses a different field, update call sites through that constant rather than hardcoding a new string.
