# MongoDB Queries — Reference

All queries are **read-only** (`find_one` / `find` / `admin.command("ping")`). Nothing in this app ever writes, updates, or deletes data. Source of truth: `db_service.py`.

Email matching is done in a single MongoDB query using case-insensitive, anchored regex against the `userEmail` field:

```python
pattern = f'^"?{re.escape(email.strip())}"?$'
{
    "userEmail": {"$regex": pattern, "$options": "i"},
    "_deleted": {"$ne": True},
}
```

The optional `"?` on each side tolerates stored values that carry literal
surrounding double-quote characters (a leftover from a bad CSV/JSON import),
e.g. a field whose actual value is the string `"demo@email.com"` rather than
`demo@email.com`.

`"_deleted": {"$ne": True}` excludes soft-deleted association documents —
`profile_associations` (and possibly other collections) can carry an old,
deleted record alongside the live one for the same email; without this
filter `find_one` has no ordering guarantee and could silently return the
stale/deleted document instead of the live one. Collections that don't have
an `_deleted` field at all are unaffected — a missing field is never equal
to `True`, so the filter still matches them normally.

---

## 1. Connection test (on save / on status check)

```python
client.admin.command("ping")
```
Run by: `db_service.test_connection()` — used by `/api/config` (POST) when saving a new URI, and by `/api/config/status` (GET) on every page load.

---

## 2. Persona + profile resolution (always runs, every lookup)

**`ExxatNetwork.profile_associations`** — find the association document for the entered email:

```python
db.ExxatNetwork.profile_associations.find_one({
  "userEmail": { "$regex": "^<email>$", "$options": "i" }
})
# fallback if no match:
db.ExxatNetwork.profile_associations.find_one({
  "email": { "$regex": "^<email>$", "$options": "i" }
})
```
Fields read from the result: `persona`, `oneProfileId`, `active`, `oneSchoolId` (School persona only), `tenantId` (Site persona only).

**`ExxatNetwork.master_profiles`** — resolve the person's name, always run if `oneProfileId` was present:

```python
db.ExxatNetwork.master_profiles.find_one({ "_id": <oneProfileId> })
```
Fields read: `firstName`, `lastName`.

---

## 3. Persona-specific branch

### If persona == "Student"

**`Rubix.assignees`** — find the assignee record for the same email:

```python
db.Rubix.assignees.find_one({
  "userEmail": { "$regex": "^<email>$", "$options": "i" }
})
# fallback:
db.Rubix.assignees.find_one({
  "email": { "$regex": "^<email>$", "$options": "i" }
})
```
Fields read: `_id`, `oneSchoolId`, `tenantId`.

**`Rubix.tenant_schools`** — school details, only if `oneSchoolId` present:

```python
db.Rubix.tenant_schools.find_one({ "_id": <assignee.oneSchoolId> })
```
Fields read: `name`, `active`, `addresses[].contacts[]` (flattened into POC contact list: `firstName`, `lastName`, `userEmail`, `type`).

**`Rubix.tenant_sites`** — site details, only if `tenantId` present:

```python
db.Rubix.tenant_sites.find_one({ "_id": <assignee.tenantId> })
```
Fields read: same shape as `tenant_schools` (`name`, `active`, `addresses[].contacts[]`).

**`Rubix.assignments`** — every assignment for this assignee (can be multiple):

```python
db.Rubix.assignments.find({ "assigneeId": <assignee._id> })
```
Fields read per document: `policy.stdCanViewAsnm`, `subscription.payStatus`, `availabilities[].name`/`active`, `startDate`, `endDate`, `ofb.compliant`/`groups`, `onb.compliant`/`groups`, `caas.compliant`.

### If persona == "School"

`oneSchoolId` is read directly off the `profile_associations` document (no `assignees` hop):

```python
db.Rubix.tenant_schools.find_one({ "_id": <association.oneSchoolId> })
```
No Site card, no assignments for this persona.

### If persona == "Site"

`tenantId` is read directly off the `profile_associations` document:

```python
db.Rubix.tenant_sites.find_one({ "_id": <association.tenantId> })
```
No School card, no assignments for this persona.

---

## Query count per lookup (worst case)

| Persona | Queries issued |
|---|---|
| Student | profile_associations (1–2 attempts) + master_profiles (1) + assignees (1–2 attempts) + tenant_schools (1) + tenant_sites (1) + assignments (1) = **up to 7** |
| School | profile_associations (1–2) + master_profiles (1) + tenant_schools (1) = **up to 4** |
| Site | profile_associations (1–2) + master_profiles (1) + tenant_sites (1) = **up to 4** |

The "1–2 attempts" comes from the `userEmail` → `email` fallback in `_find_by_email`; it stops at the first match, so it's only 2 queries when `userEmail` doesn't match and `email` does.
