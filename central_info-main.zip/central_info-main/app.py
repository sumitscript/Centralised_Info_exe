import logging
import os
import sys
import time
from datetime import datetime

from bson import ObjectId
from flask import Flask, jsonify, render_template, request
from flask.json.provider import DefaultJSONProvider
from pymongo.errors import PyMongoError

import config_store
import db_service
from db_service import LookupError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stdout,
    force=True,
)
log = logging.getLogger("centralised_info")

if getattr(sys, "frozen", False):
    BASE_DIR = sys._MEIPASS
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)


def _asset_version(rel_path: str) -> int:
    """mtime of the static file, used as a cache-busting query param so the
    browser can never serve a stale cached copy after an edit - no amount
    of Cache-Control header guessing needed."""
    try:
        return int(os.path.getmtime(os.path.join(STATIC_DIR, rel_path)))
    except OSError:
        return 0


class MongoSafeJSONProvider(DefaultJSONProvider):
    @staticmethod
    def default(obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        if isinstance(obj, datetime):
            return obj.isoformat()
        return DefaultJSONProvider.default(obj)


app = Flask(__name__)
app.json_provider_class = MongoSafeJSONProvider
app.json = MongoSafeJSONProvider(app)
app.jinja_env.globals["asset_version"] = _asset_version


@app.after_request
def disable_caching(response):
    # Dev tool iterating fast on static JS/CSS - never let the browser
    # serve a stale cached copy after an edit.
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/config/status")
def config_status():
    uri = config_store.load_uri()
    if not uri:
        return jsonify({"configured": False, "connected": False, "maskedUri": None})

    ok, message = db_service.test_connection(uri)
    return jsonify(
        {
            "configured": True,
            "connected": ok,
            "message": None if ok else message,
            "maskedUri": "••••••••••••••••••••••••",
        }
    )


@app.route("/api/config", methods=["POST"])
def save_config():
    data = request.get_json(silent=True) or {}
    uri = (data.get("uri") or "").strip()
    if not uri:
        return jsonify({"ok": False, "message": "Connection string is required."}), 400

    # Handle bullet dots placeholder (retain existing configured URI if user didn't modify it)
    if uri == "••••••••••••••••••••••••":
        saved = config_store.load_uri()
        if saved:
            uri = saved

    ok, message = db_service.test_connection(uri)
    if not ok:
        return jsonify({"ok": False, "message": message}), 400

    config_store.save_uri(uri)
    return jsonify({"ok": True, "maskedUri": "••••••••••••••••••••••••"})


@app.route("/api/config", methods=["DELETE"])
def clear_config():
    config_store.clear_uri()
    return jsonify({"ok": True})


@app.route("/api/lookup")
def lookup():
    email = (request.args.get("email") or "").strip()
    if not email:
        return jsonify({"ok": False, "message": "Email is required."}), 400

    if email.lower().endswith("@exxat.com"):
        return jsonify({"ok": False, "message": "Searching for @exxat.com internal emails is restricted."}), 400

    uri = config_store.load_uri()
    if not uri:
        return jsonify({"ok": False, "message": "No MongoDB connection configured."}), 400

    try:
        db_service.get_client()
    except LookupError:
        ok, message = db_service.test_connection(uri)
        if not ok:
            log.warning("Initial connect failed for lookup(%s): %s", email, message)
            return jsonify({"ok": False, "message": message}), 400

    max_attempts = 3
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            result = db_service.lookup_email(email)
            return jsonify({"ok": True, "data": result})
        except LookupError as exc:
            return jsonify({"ok": False, "message": str(exc)}), 404
        except PyMongoError as exc:
            last_error = exc
            log.warning(
                "Attempt %d/%d: Mongo connection dropped during lookup(%s): %s",
                attempt, max_attempts, email, exc,
            )
            if attempt < max_attempts:
                time.sleep(0.5 * attempt)
                try:
                    db_service.connect(uri)
                except PyMongoError as reconnect_exc:
                    log.warning("Reconnect failed: %s", reconnect_exc)
        except Exception as exc:  # noqa: BLE001 - surface to the UI as a friendly error
            log.exception("Unexpected error during lookup(%s)", email)
            return jsonify({"ok": False, "message": f"Query failed: {exc}"}), 500

    log.error("Lookup(%s) failed after %d attempts: %s", email, max_attempts, last_error)
    return jsonify(
        {
            "ok": False,
            "message": (
                f"Lost connection to MongoDB after {max_attempts} attempts "
                f"({last_error}). This is usually a network/firewall/VPN "
                "resetting the connection to Atlas, not an app bug."
            ),
        }
    ), 502


@app.route("/api/debug/by-id")
def debug_by_id():
    """Full persona/profile/school/site/assignments resolution, starting
    from a profile_associations _id instead of an email."""
    id_str = (request.args.get("id") or "").strip()
    if not id_str:
        return jsonify({"ok": False, "message": "id is required."}), 400

    uri = config_store.load_uri()
    if not uri:
        return jsonify({"ok": False, "message": "No MongoDB connection configured."}), 400

    try:
        db_service.get_client()
    except LookupError:
        ok, message = db_service.test_connection(uri)
        if not ok:
            return jsonify({"ok": False, "message": message}), 400

    try:
        result = db_service.lookup_by_association_id(id_str)
        return jsonify({"ok": True, "data": result})
    except LookupError as exc:
        return jsonify({"ok": False, "message": str(exc)}), 404
    except PyMongoError as exc:
        log.exception("Debug by-id query failed for %s", id_str)
        return jsonify({"ok": False, "message": f"Query failed: {exc}"}), 502


@app.route("/api/search/school")
def search_school():
    query = (request.args.get("q") or request.args.get("name") or "").strip()
    if not query:
        return jsonify({"ok": False, "message": "School query is required."}), 400

    uri = config_store.load_uri()
    if not uri:
        return jsonify({"ok": False, "message": "No MongoDB connection configured."}), 400

    try:
        db_service.get_client()
    except LookupError:
        ok, message = db_service.test_connection(uri)
        if not ok:
            return jsonify({"ok": False, "message": message}), 400

    try:
        result = db_service.search_school(query)
        return jsonify({"ok": True, "data": result})
    except LookupError as exc:
        return jsonify({"ok": False, "message": str(exc)}), 404
    except PyMongoError as exc:
        log.exception("School search failed for %s", query)
        return jsonify({"ok": False, "message": f"Query failed: {exc}"}), 502


@app.route("/api/search/site")
def search_site():
    query = (request.args.get("q") or request.args.get("name") or "").strip()
    if not query:
        return jsonify({"ok": False, "message": "Clinical site query is required."}), 400

    uri = config_store.load_uri()
    if not uri:
        return jsonify({"ok": False, "message": "No MongoDB connection configured."}), 400

    try:
        db_service.get_client()
    except LookupError:
        ok, message = db_service.test_connection(uri)
        if not ok:
            return jsonify({"ok": False, "message": message}), 400

    try:
        result = db_service.search_site(query)
        return jsonify({"ok": True, "data": result})
    except LookupError as exc:
        return jsonify({"ok": False, "message": str(exc)}), 404
    except PyMongoError as exc:
        log.exception("Site search failed for %s", query)
        return jsonify({"ok": False, "message": f"Query failed: {exc}"}), 502


if __name__ == "__main__":
    import threading
    import webbrowser

    def _open_browser():
        time.sleep(1.0)
        webbrowser.open("http://127.0.0.1:5050")

    threading.Thread(target=_open_browser, daemon=True).start()
    log.info("Starting Centralised Info on http://127.0.0.1:5050")
    app.run(host="127.0.0.1", port=5050)

