const state = {
  history: [],       // [{email, data}]
  activeEmail: null,
  configured: false,
};

const el = (id) => document.getElementById(id);

const connIndicator = el("connIndicator");
const connDot = el("connDot");
const connText = el("connText");
const emailInput = el("emailInput");
const historyRow = el("historyRow");
const statusBanner = el("statusBanner");

const configBackdrop = el("configBackdrop");
const uriInput = el("uriInput");
const modalMsg = el("modalMsg");
const saveConfigBtn = el("saveConfigBtn");
const cancelConfigBtn = el("cancelConfigBtn");
const clearConfigBtn = el("clearConfigBtn");
clearConfigBtn.style.display = "none";

function setConnState(mode, label) {
  connDot.className = "dot" + (mode ? ` ${mode}` : "");
  connText.textContent = label;
}

async function refreshConnStatus() {
  setConnState("pending", "Checking…");
  try {
    const res = await fetch("/api/config/status");
    const data = await res.json();
    state.configured = !!data.configured;
    if (!data.configured) {
      setConnState("", "Not connected");
    } else if (data.connected) {
      setConnState("ok", "Connected");
    } else {
      setConnState("", data.message || "Connection failed");
    }
  } catch {
    state.configured = false;
    setConnState("", "Not connected");
  }
  updateClearButtonVisibility();
}

function updateClearButtonVisibility() {
  clearConfigBtn.style.display = state.configured ? "" : "none";
}

function showModal() {
  modalMsg.textContent = "";
  modalMsg.className = "modal-msg";
  uriInput.value = "";
  updateClearButtonVisibility();
  configBackdrop.classList.remove("hidden");
  uriInput.focus();
}
function hideModal() {
  configBackdrop.classList.add("hidden");
}

connIndicator.addEventListener("click", showModal);
cancelConfigBtn.addEventListener("click", hideModal);
configBackdrop.addEventListener("click", (e) => {
  if (e.target === configBackdrop) hideModal();
});

saveConfigBtn.addEventListener("click", async () => {
  const uri = uriInput.value.trim();
  if (!uri) return;
  saveConfigBtn.textContent = "Testing…";
  saveConfigBtn.disabled = true;
  try {
    const res = await fetch("/api/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ uri }),
    });
    const data = await res.json();
    if (data.ok) {
      modalMsg.textContent = "Connected and saved.";
      modalMsg.className = "modal-msg ok";
      await refreshConnStatus();
      setTimeout(hideModal, 700);
    } else {
      modalMsg.textContent = data.message || "Connection failed.";
      modalMsg.className = "modal-msg bad";
    }
  } catch (err) {
    modalMsg.textContent = "Request failed: " + err;
    modalMsg.className = "modal-msg bad";
  } finally {
    saveConfigBtn.textContent = "Test & Save";
    saveConfigBtn.disabled = false;
  }
});

clearConfigBtn.addEventListener("click", async () => {
  await fetch("/api/config", { method: "DELETE" });
  await refreshConnStatus();
  hideModal();
});

function showBanner(message) {
  statusBanner.textContent = message;
  statusBanner.classList.remove("hidden");
}
function hideBanner() {
  statusBanner.classList.add("hidden");
}

emailInput.addEventListener("keydown", async (e) => {
  if (e.key !== "Enter") return;
  const email = emailInput.value.trim();
  if (!email) return;
  await runSearch(email);
});

async function runSearch(email) {
  hideBanner();
  const cached = state.history.find((h) => h.email.toLowerCase() === email.toLowerCase());
  if (cached) {
    state.activeEmail = email;
    renderResult(cached.data);
    renderHistory();
    if (cached.data._debug) debugIdResult.textContent = JSON.stringify(cached.data._debug, null, 2);
    return;
  }

  emailInput.disabled = true;
  try {
    const res = await fetch(`/api/lookup?email=${encodeURIComponent(email)}`);
    const data = await res.json();
    if (!data.ok) {
      showBanner(data.message || "Lookup failed.");
      return;
    }
    state.history.unshift({ email, data: data.data });
    state.activeEmail = email;
    renderResult(data.data);
    renderHistory();
    if (data.data._debug) debugIdResult.textContent = JSON.stringify(data.data._debug, null, 2);
  } catch (err) {
    showBanner("Request failed: " + err);
  } finally {
    emailInput.disabled = false;
    emailInput.focus();
  }
}

function renderHistory() {
  historyRow.innerHTML = "";
  state.history.forEach((h) => {
    const chip = document.createElement("div");
    chip.className = "history-chip" + (h.email === state.activeEmail ? " active" : "");
    chip.textContent = h.email;
    chip.addEventListener("click", () => {
      emailInput.value = h.email;
      state.activeEmail = h.email;
      renderResult(h.data);
      renderHistory();
    });
    historyRow.appendChild(chip);
  });
}

function renderResult(data) {
  el("personaBadge").textContent = data.persona || "—";

  const profileBody = el("profileBody");
  const userActiveBadge = `<span class="badge ${data.userActive ? "ok" : "bad"}">${data.userActive ? "User Active" : "User Inactive"}</span>`;
  if (data.profile) {
    profileBody.innerHTML = `
      <div class="profile-name">${escapeHtml(data.profile.firstName)} ${escapeHtml(data.profile.lastName)}</div>
      <div class="profile-email">${escapeHtml(data.email)}</div>
      <div class="badge-row" style="margin-top:10px;">${userActiveBadge}</div>
    `;
  } else {
    profileBody.innerHTML = `<p class="empty-hint">Profile not found.</p><div class="badge-row" style="margin-top:10px;">${userActiveBadge}</div>`;
  }

  renderOrgCard("schoolBody", data.school, "school");
  renderOrgCard("siteBody", data.site, "site");

  const section = el("assignmentsSection");
  const list = el("assignmentsList");
  list.innerHTML = "";
  if (data.assignments && data.assignments.length) {
    section.style.display = "";
    data.assignments.forEach((a) => list.appendChild(renderAssignmentCard(a)));
  } else {
    section.style.display = "none";
  }
}

function renderOrgCard(bodyId, org, kind) {
  const body = el(bodyId);
  if (!org) {
    body.innerHTML = `<p class="empty-hint">No ${kind} on record.</p>`;
    return;
  }
  const contactsHtml = org.contacts.length
    ? org.contacts
        .map(
          (c) => `
        <div class="contact-row">
          <span class="contact-name">${escapeHtml(c.firstName)} ${escapeHtml(c.lastName)}</span>
          <span class="contact-meta">${escapeHtml(c.email)}${c.type ? " · " + escapeHtml(c.type) : ""}</span>
        </div>`
        )
        .join("")
    : `<p class="empty-hint">No POC contacts listed.</p>`;

  const kindLabel = kind.charAt(0).toUpperCase() + kind.slice(1);
  const activeBadge = `<div class="badge-row" style="margin-bottom:10px;"><span class="badge ${org.active ? "ok" : "bad"}">${org.active ? kindLabel + " Active" : kindLabel + " Inactive"}</span></div>`;

  body.innerHTML = `<div class="org-name">${escapeHtml(org.name)}</div>${activeBadge}${contactsHtml}`;
}

function renderAssignmentCard(a) {
  const wrap = document.createElement("div");
  wrap.className = "assignment-card";

  const availHtml = (a.availabilities || [])
    .map(
      (av) =>
        `<span class="avail-chip${av.active ? "" : " inactive"}">${escapeHtml(av.name)}</span>`
    )
    .join("");

  wrap.innerHTML = `
    <div class="assignment-top">
      <div class="badge-row">
        <span class="badge ${a.studentConfirmed ? "ok" : "bad"}">${a.studentConfirmed ? "Student Confirmed" : "Not Confirmed"}</span>
        <span class="badge ${a.paymentDone ? "ok" : "bad"}">${a.paymentDone ? "Payment Done" : (a.payStatus || "Payment Pending")}</span>
        <span class="badge ${a.onboarding.compliant ? "ok" : "bad"}">${a.onboarding.compliant ? "Onboarding Compliant" : "Onboarding Not Compliant"}</span>
        <span class="badge ${a.offboarding.compliant ? "ok" : "bad"}">${a.offboarding.compliant ? "Offboarding Compliant" : "Offboarding Not Compliant"}</span>
        <span class="badge ${a.caas.compliant ? "ok" : "bad"}">${a.caas.compliant ? "CAAS Compliant" : "CAAS Not Compliant"}</span>
      </div>
      <div class="assignment-dates">${a.startDate || "—"} → ${a.endDate || "—"}</div>
    </div>
    <div class="availability-list">${availHtml}</div>
  `;
  return wrap;
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const debugIdInput = el("debugIdInput");
const debugIdResult = el("debugIdResult");

debugIdInput.addEventListener("keydown", async (e) => {
  if (e.key !== "Enter") return;
  const id = debugIdInput.value.trim();
  if (!id) return;
  hideBanner();
  debugIdResult.textContent = "Querying…";
  try {
    const res = await fetch(`/api/debug/by-id?id=${encodeURIComponent(id)}`);
    const data = await res.json();
    debugIdResult.textContent = JSON.stringify(data, null, 2);
    if (data.ok) {
      state.activeEmail = data.data.email || id;
      state.history.unshift({ email: state.activeEmail, data: data.data });
      renderResult(data.data);
      renderHistory();
    } else {
      showBanner(data.message || "Lookup by _id failed.");
    }
  } catch (err) {
    debugIdResult.textContent = "Request failed: " + err;
  }
});

refreshConnStatus();
