import json
import logging
import os
import sys
import time
from datetime import datetime

from bson import ObjectId
from bson.errors import InvalidId
from pymongo import MongoClient
from pymongo.errors import PyMongoError

log = logging.getLogger("mongo_lookup")


def configure_logging(level: str | int | None = None, stream=sys.stderr) -> logging.Logger:
    if level is None:
        level = os.environ.get("MONGO_LOOKUP_LOG", "INFO")
    if isinstance(level, str):
        level = getattr(logging, level.strip().upper(), logging.INFO)

    if not any(getattr(h, "_mongo_lookup_handler", False) for h in log.handlers):
        handler = logging.StreamHandler(stream)
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)-5s [mongo_lookup] %(message)s",
                datefmt="%H:%M:%S",
            )
        )
        handler._mongo_lookup_handler = True
        log.addHandler(handler)

    log.setLevel(level)
    log.propagate = False
    return log


def set_log_level(level: str | int) -> None:
    configure_logging(level)


configure_logging()


def _redact_uri(uri: str) -> str:
    try:
        scheme, rest = uri.split("://", 1)
        if "@" in rest:
            creds, host = rest.split("@", 1)
            user = creds.split(":", 1)[0]
            return f"{scheme}://{user}:***@{host}"
        return f"{scheme}://{rest}"
    except Exception:
        return "<unparseable uri>"


def _log_query(db: str, collection: str, op: str, filt: dict) -> float:
    try:
        formatted_filt = json.dumps(filt, indent=2, default=str)
    except Exception:
        formatted_filt = str(filt)
    log.info("QUERY  %s.%s.%s:\n%s", db, collection, op, formatted_filt)
    return time.perf_counter()


def _log_result(db: str, collection: str, started: float, doc, label: str = "doc") -> None:
    ms = (time.perf_counter() - started) * 1000
    if doc is None:
        log.info("RESULT %s.%s -> no %s (%.1f ms)", db, collection, label, ms)
        return
    if isinstance(doc, int):
        log.info("RESULT %s.%s -> %d %s(s) (%.1f ms)", db, collection, doc, label, ms)
        return
    try:
        formatted_doc = json.dumps(doc, indent=2, default=str)
    except Exception:
        formatted_doc = str(doc)
    doc_id = doc.get("_id") if isinstance(doc, dict) else ""
    log.info("RESULT %s.%s (_id=%s, %.1f ms):\n%s", db, collection, doc_id, ms, formatted_doc)


_client: MongoClient | None = None


class LookupError(Exception):
    pass


def connect(uri: str, timeout_ms: int = 20000) -> MongoClient:
    """Open (and store as the shared, long-lived) Mongo client with resilient connection pooling."""
    global _client
    log.debug(
        "CONNECT options serverSelectionTimeoutMS=%d connectTimeoutMS=%d "
        "socketTimeoutMS=20000 maxIdleTimeMS=45000 retryReads=True maxPoolSize=10",
        max(timeout_ms, 30000),
        timeout_ms,
    )
    started = time.perf_counter()
    client = MongoClient(
        uri,
        serverSelectionTimeoutMS=max(timeout_ms, 30000),
        connectTimeoutMS=timeout_ms,
        socketTimeoutMS=20000,
        maxIdleTimeMS=45000,
        retryReads=True,
        retryWrites=True,
        maxPoolSize=10,
        minPoolSize=0,
    )
    log.info("CONNECT sending admin ping ...")
    try:
        client.admin.command("ping")
    except PyMongoError as exc:
        log.error(
            "CONNECT ping FAILED after %.1f ms: %s: %s",
            (time.perf_counter() - started) * 1000,
            type(exc).__name__,
            exc,
        )
        raise
    log.info("CONNECT ping ok (%.1f ms)", (time.perf_counter() - started) * 1000)
    _client = client
    return client


def get_client() -> MongoClient:
    """Get the active MongoClient instance, automatically re-connecting if idle or dropped."""
    global _client
    if _client is None:
        from config_store import load_uri
        saved_uri = load_uri()
        if saved_uri:
            try:
                log.info("STEP   get_client -> auto-connecting using stored configuration...")
                return connect(saved_uri)
            except Exception as exc:
                log.error("STEP   get_client -> auto-connect failed: %s", exc)
                raise LookupError("Failed to connect to MongoDB with stored configuration.")
        log.error("STEP   get_client -> no active client (connect() not called)")
        raise LookupError("Not connected to MongoDB. Please configure Mongo URI.")

    # Perform lightweight socket health check
    try:
        _client.admin.command("ping")
    except Exception as exc:
        log.warning("STEP   get_client -> connection check failed (%s). Re-connecting...", exc)
        _client = None
        from config_store import load_uri
        saved_uri = load_uri()
        if saved_uri:
            return connect(saved_uri)
        raise LookupError("Connection to MongoDB was lost and no saved configuration found.")

    log.debug("STEP   get_client -> reusing active client")
    return _client


def test_connection(uri: str) -> tuple[bool, str]:
    log.info("STEP   test_connection start")
    try:
        connect(uri)
        log.info("STEP   test_connection -> Connected")
        return True, "Connected"
    except PyMongoError as exc:
        log.error("STEP   test_connection -> FAILED: %s: %s", type(exc).__name__, exc)
        return False, str(exc)


EMAIL_FIELD_NAME = "userEmail"


def _find_by_email(collection, email: str) -> dict | None:
    """Return the first matching non-deleted document by userEmail."""
    docs = _find_all_by_email(collection, email)
    return docs[0] if docs else None


def _find_all_by_email(collection, email: str) -> list[dict]:
    """Search for non-deleted documents matching userEmail using initial case-insensitive regex for user input."""
    db_name = collection.database.name
    coll_name = collection.name
    clean_email = str(email).strip()
    pattern = f'^"?{_escape(clean_email)}"?$'
    log.info("STEP   _find_all_by_email %s.%s email=%r", db_name, coll_name, clean_email)

    filt = {
        EMAIL_FIELD_NAME: {"$regex": pattern, "$options": "i"},
        "_deleted": {"$ne": True},
    }
    started = _log_query(db_name, coll_name, "find", filt)
    cursor = collection.find(filt)
    docs = list(cursor)
    _log_result(db_name, coll_name, started, len(docs), label="match")

    if not docs:
        log.warning(
            "STEP   _find_all_by_email no match in %s.%s for userEmail=%r",
            db_name,
            coll_name,
            clean_email,
        )
    return docs


def _escape(text: str) -> str:
    import re

    return re.escape(text.strip())


def _fmt_date(value) -> str | None:
    if isinstance(value, datetime):
        return value.strftime("%d/%m/%Y")
    return None


def _format_address_obj(addr: dict) -> str:
    if not isinstance(addr, dict):
        return ""
    line1 = (addr.get("addressLine1") or addr.get("address1") or addr.get("street") or addr.get("street1") or addr.get("address") or "").strip()
    line2 = (addr.get("addressLine2") or addr.get("address2") or addr.get("street2") or addr.get("suite") or addr.get("unit") or "").strip()
    city = (addr.get("city") or "").strip()
    state = (addr.get("state") or addr.get("province") or "").strip()
    zip_code = (addr.get("zip") or addr.get("zipCode") or addr.get("postalCode") or addr.get("zipcode") or "").strip()
    country = (addr.get("country") or "").strip()

    street_part = " ".join(filter(None, [line1, line2]))
    location_part = ", ".join(filter(None, [city, " ".join(filter(None, [state, zip_code]))]))
    
    parts = [p for p in [street_part, location_part, country] if p]
    return ", ".join(parts)


def _extract_combined_address(doc: dict) -> str:
    addresses = doc.get("addresses", []) or []
    formatted_list = []
    if isinstance(addresses, list):
        for addr in addresses:
            f = _format_address_obj(addr)
            if f and f not in formatted_list:
                formatted_list.append(f)
    elif isinstance(addresses, dict):
        f = _format_address_obj(addresses)
        if f:
            formatted_list.append(f)

    if not formatted_list:
        top_f = _format_address_obj(doc)
        if top_f:
            formatted_list.append(top_f)

    return "; ".join(formatted_list) if formatted_list else ""


def _get_user_type(doc: dict | None) -> str:
    """Extract userType / user_type from document or sub-document tags."""
    if not doc or not isinstance(doc, dict):
        return ""
    
    # Check direct userType / user_type field
    ut = doc.get("userType") or doc.get("user_type") or ""
    if ut:
        return str(ut).strip()

    # Check tags sub-document or list
    tags = doc.get("tags")
    if isinstance(tags, dict):
        ut = tags.get("userType") or tags.get("user_type") or ""
        if ut:
            return str(ut).strip()
    elif isinstance(tags, list):
        for item in tags:
            if isinstance(item, dict):
                ut = item.get("userType") or item.get("user_type") or ""
                if ut:
                    return str(ut).strip()
            elif isinstance(item, str):
                item_clean = item.strip().lower()
                if item_clean in ("faculty", "school faculty"):
                    return "Faculty"
                elif ":" in item and "usertype" in item.lower():
                    return item.split(":", 1)[1].strip()

    return ""


def _is_exxat_email(email: str | None) -> bool:
    """Check if an email address belongs to the restricted @exxat.com domain."""
    if not email or not isinstance(email, str):
        return False
    return email.strip().lower().endswith("@exxat.com")


def _extract_contacts(doc: dict) -> list[dict]:
    contacts = []
    addresses = doc.get("addresses", []) or []
    log.debug("STEP   _extract_contacts addresses=%d", len(addresses))
    for address in addresses:
        for c in address.get("contacts", []) or []:
            c_email = (c.get("userEmail") or c.get("email") or "").strip()
            if _is_exxat_email(c_email):
                log.info("STEP   _extract_contacts -> filtering out @exxat.com contact email=%r", c_email)
                continue
            c_type = c.get("type", "")
            user_type = _get_user_type(c) or _get_user_type(doc)
            if user_type.lower() in ("faculty", "school faculty"):
                if "school" in c_type.lower() or not c_type or c_type.lower() in ("admin", "school admin", "primary contact"):
                    c_type = "School Faculty"
                else:
                    c_type = "Faculty"
            contacts.append(
                {
                    "firstName": c.get("firstName", ""),
                    "lastName": c.get("lastName", ""),
                    "email": c_email,
                    "type": c_type,
                    "userType": user_type,
                }
            )
    log.info("STEP   _extract_contacts -> %d contact(s)", len(contacts))
    return contacts


def _prism_tag(doc: dict) -> str:
    """School-only check: prismTenantId (string) vs _id (ObjectId).
    Match -> "No Prism", mismatch/missing -> "Prism"."""
    doc_id = doc.get("_id")
    prism_tenant_id = doc.get("prismTenantId")
    is_match = bool(prism_tenant_id) and str(doc_id) == str(prism_tenant_id)
    tag = "No Prism" if is_match else "Prism"
    log.info(
        "STEP   _prism_tag _id=%s prismTenantId=%r -> %s",
        doc_id,
        prism_tenant_id,
        tag,
    )
    return tag


def _org_summary(doc: dict | None, is_school: bool = False) -> dict | None:
    if not doc:
        log.info("STEP   _org_summary -> None (no document)")
        return None
    summary = {
        "_id": str(doc.get("_id", "")),
        "name": doc.get("name", ""),
        "active": bool(doc.get("active", False)),
        "address": _extract_combined_address(doc),
        "contacts": _extract_contacts(doc),
    }
    if is_school:
        summary["prismTag"] = _prism_tag(doc)
    log.info(
        "STEP   _org_summary -> _id=%s name=%r active=%s contacts=%d address=%r%s",
        summary["_id"],
        summary["name"],
        summary["active"],
        len(summary["contacts"]),
        summary["address"],
        f" prismTag={summary['prismTag']}" if is_school else "",
    )
    return summary


def _fetch_partner_sites_for_school(school_id) -> list[dict]:
    """Find all clinical sites partnered with the specified school_id using Rubix.partners."""
    if not school_id:
        return []
    try:
        if isinstance(school_id, str):
            school_id = ObjectId(school_id)
    except Exception:
        pass

    client = get_client()
    rubix = client["Rubix"]

    coll_name = "partners"
    partners_coll = rubix[coll_name]

    filt = {
        "$or": [
            {"oneSchoolId": school_id},
            {"schoolId": school_id},
            {"tenantSchoolId": school_id},
        ],
        "_deleted": {"$ne": True},
    }
    q_started = _log_query("Rubix", coll_name, "find", filt)
    partner_docs = list(partners_coll.find(filt))
    _log_result("Rubix", coll_name, q_started, len(partner_docs), label="school_partnerships")

    if not partner_docs:
        return []

    site_active_map = {}
    site_ids = []
    for doc in partner_docs:
        tid = doc.get("tenantId") or doc.get("siteId") or doc.get("tenantSiteId")
        if tid and tid not in site_active_map:
            is_active = bool(doc.get("active", True))
            site_active_map[tid] = is_active
            site_ids.append(tid)

    if not site_ids:
        return []

    q_sites_started = _log_query("Rubix", "tenant_sites", "find", {"_id": {"$in": site_ids}})
    site_docs = list(rubix["tenant_sites"].find({"_id": {"$in": site_ids}}))
    _log_result("Rubix", "tenant_sites", q_sites_started, len(site_docs), label="partner_sites")

    results = []
    for s_doc in site_docs:
        s_summary = _org_summary(s_doc)
        if s_summary:
            s_id = s_doc.get("_id")
            s_summary["partnerActive"] = site_active_map.get(s_id, True)
            if s_id != str(s_doc.get("_id")):
                s_summary["partnerActive"] = site_active_map.get(str(s_doc.get("_id")), True)
            results.append(s_summary)

    return results


def _fetch_partner_schools_for_site(site_id) -> list[dict]:
    """Find all schools partnered with the specified site_id using Rubix.partners."""
    if not site_id:
        return []
    try:
        if isinstance(site_id, str):
            site_id = ObjectId(site_id)
    except Exception:
        pass

    client = get_client()
    rubix = client["Rubix"]

    coll_name = "partners"
    partners_coll = rubix[coll_name]

    filt = {
        "$or": [
            {"tenantId": site_id},
            {"siteId": site_id},
            {"tenantSiteId": site_id},
        ],
        "_deleted": {"$ne": True},
    }
    q_started = _log_query("Rubix", coll_name, "find", filt)
    partner_docs = list(partners_coll.find(filt))
    _log_result("Rubix", coll_name, q_started, len(partner_docs), label="site_partnerships")

    if not partner_docs:
        return []

    school_active_map = {}
    school_ids = []
    for doc in partner_docs:
        sid = doc.get("oneSchoolId") or doc.get("schoolId") or doc.get("tenantSchoolId")
        if sid and sid not in school_active_map:
            is_active = bool(doc.get("active", True))
            school_active_map[sid] = is_active
            school_ids.append(sid)

    if not school_ids:
        return []

    q_schools_started = _log_query("Rubix", "tenant_schools", "find", {"_id": {"$in": school_ids}})
    school_docs = list(rubix["tenant_schools"].find({"_id": {"$in": school_ids}}))
    _log_result("Rubix", "tenant_schools", q_schools_started, len(school_docs), label="partner_schools")

    results = []
    for sc_doc in school_docs:
        sc_summary = _org_summary(sc_doc, is_school=True)
        if sc_summary:
            sc_id = sc_doc.get("_id")
            sc_summary["partnerActive"] = school_active_map.get(sc_id, True)
            if sc_id != str(sc_doc.get("_id")):
                sc_summary["partnerActive"] = school_active_map.get(str(sc_doc.get("_id")), True)
            results.append(sc_summary)

    return results


def _assignment_summary(doc: dict) -> dict:
    log.debug("STEP   _assignment_summary _id=%s", doc.get("_id"))
    policy = doc.get("policy", {}) or {}
    subscription = policy.get("subscription", {}) or {}
    ofb = doc.get("ofb", {}) or {}
    onb = doc.get("onb", {}) or {}
    caas = doc.get("caas", {}) or {}
    availabilities = [
        {"name": a.get("name", ""), "active": bool(a.get("active", False))}
        for a in (doc.get("availabilities", []) or [])
    ]
    display_id = doc.get("displayId") or policy.get("displayId") or doc.get("display_id") or ""
    assignment_tenant_id = doc.get("tenantId") or doc.get("siteId") or doc.get("tenantSiteId")
    doc_id = doc.get("_id")
    group_id = doc.get("groupId")
    is_individual = bool(group_id) and str(group_id) == str(doc_id)
    assignment_type = "Individual Assignment" if is_individual else "Group Assignment"
    log.info(
        "STEP   _assignment_summary _id=%s groupId=%r -> %s",
        doc_id,
        group_id,
        assignment_type,
    )
    summary = {
        "id": str(doc.get("_id", "")),
        "tenantId": str(assignment_tenant_id) if assignment_tenant_id else None,
        "assignmentType": assignment_type,
        "displayId": str(display_id).strip() if display_id else None,
        "studentConfirmed": bool(policy.get("stdCanViewAsnm", False)),
        "paymentDone": subscription.get("payStatus") == "Paid",
        "payStatus": subscription.get("payStatus"),
        "availabilities": availabilities,
        "startDate": _fmt_date(doc.get("startDate")),
        "endDate": _fmt_date(doc.get("endDate")),
        "offboarding": {
            "compliant": bool(ofb.get("compliant", False)),
            "groups": [str(g) for g in (ofb.get("groups", []) or [])],
        },
        "onboarding": {
            "compliant": bool(onb.get("compliant", False)),
            "groups": [str(g) for g in (onb.get("groups", []) or [])],
        },
        "caas": {
            "compliant": bool(caas.get("compliant", False)),
        },
    }
    # --- payment check diagnostics -------------------------------------
    # paymentDone is a strict, case- and whitespace-sensitive equality
    # against "Paid". Log exactly why it came out the way it did so a
    # casing/quote/spacing artifact in the data is visible in the terminal
    # instead of silently surfacing as "unpaid" on the dashboard.
    raw_status = subscription.get("payStatus")
    if doc.get("subscription") is None:
        log.info(
            "PAY    id=%s no subscription sub-document -> payStatus=None paymentDone=False",
            summary["id"],
        )
    elif raw_status is None:
        log.info(
            "PAY    id=%s subscription present (%d field(s)) but payStatus missing -> paymentDone=False",
            summary["id"],
            len(subscription),
        )
    elif summary["paymentDone"]:
        log.info("PAY    id=%s payStatus=%r == 'Paid' -> paymentDone=True", summary["id"], raw_status)
    else:
        log.info(
            "PAY    id=%s payStatus=%r != 'Paid' -> paymentDone=False", summary["id"], raw_status
        )
        # Distinguish "genuinely unpaid" from "paid but stored oddly".
        if isinstance(raw_status, str) and raw_status.strip().strip('"').lower() == "paid":
            log.warning(
                "PAY    id=%s MISMATCH: payStatus=%r normalises to 'paid' but paymentDone=False "
                "(exact-match comparison). Likely casing/whitespace/quote artifact in the data.",
                summary["id"],
                raw_status,
            )
        elif not isinstance(raw_status, (str, type(None))):
            log.warning(
                "PAY    id=%s payStatus is %s (%r), not a string - comparison can never match 'Paid'.",
                summary["id"],
                type(raw_status).__name__,
                raw_status,
            )

    log.info(
        "STEP   _assignment_summary id=%s payStatus=%r paymentDone=%s confirmed=%s "
        "start=%s end=%s onb=%s ofb=%s caas=%s availabilities=%d",
        summary["id"],
        summary["payStatus"],
        summary["paymentDone"],
        summary["studentConfirmed"],
        summary["startDate"],
        summary["endDate"],
        summary["onboarding"]["compliant"],
        summary["offboarding"]["compliant"],
        summary["caas"]["compliant"],
        len(availabilities),
    )
    return summary


def _assemble_from_association(association: dict) -> dict:
    """Run the full persona -> profile/school/site/assignments resolution
    starting from an already-fetched profile_associations document."""
    overall_started = time.perf_counter()
    log.info(
        "=== STEP _assemble_from_association association._id=%s ===",
        association.get("_id"),
    )
    log.debug("STEP   association keys=%s", sorted(association.keys()))

    client = get_client()
    rubix = client["Rubix"]
    exxat_network = client["ExxatNetwork"]

    email = (association.get("userEmail") or "").strip()
    persona = str(association.get("persona") or "").strip()
    persona_lower = persona.lower()
    one_profile_id = association.get("oneProfileId")
    user_active = bool(association.get("active", False))
    log.info(
        "STEP   resolved email=%r persona=%r oneProfileId=%s userActive=%s",
        email,
        persona,
        one_profile_id,
        user_active,
    )

    profile_doc = None
    profile = None

    # Lazy helper to load master profile on-demand if name not present in persona doc
    def _fetch_master_profile():
        nonlocal profile_doc, profile
        if profile is not None:
            return profile
        if one_profile_id:
            filt = {"_id": one_profile_id}
            started = _log_query("ExxatNetwork", "master_profiles", "find_one", filt)
            profile_doc = exxat_network["master_profiles"].find_one(filt)
            _log_result("ExxatNetwork", "master_profiles", started, profile_doc, label="profile")
            if profile_doc:
                profile = {
                    "firstName": profile_doc.get("firstName", ""),
                    "lastName": profile_doc.get("lastName", ""),
                }
                log.info("STEP   profile resolved from master_profiles: firstName=%r lastName=%r", profile["firstName"], profile["lastName"])
            else:
                log.warning("STEP   master_profiles has no document for _id=%s", one_profile_id)
        else:
            log.warning("STEP   association has no oneProfileId - skipping master_profiles lookup")
        return profile

    # Non-student and non-site personas fetch master_profile immediately
    if persona_lower not in ("student", "site"):
        profile = _fetch_master_profile()

    user_type = _get_user_type(association) or _get_user_type(profile_doc)
    if user_type.lower() in ("faculty", "school faculty") or (persona_lower == "school" and user_type.lower() == "faculty"):
        persona = "School Faculty"

    result = {
        "email": email,
        "persona": persona,
        "userType": user_type,
        "profile": profile,
        "userActive": user_active,
        "school": None,
        "site": None,
        "assignments": [],
    }
    debug = {
        "personaRaw": association.get("persona"),
        "oneProfileId": str(one_profile_id) if one_profile_id else None,
        "profileFound": profile is not None,
        "associationTenantId": str(association.get("tenantId")) if association.get("tenantId") else None,
        "associationOneSchoolId": str(association.get("oneSchoolId")) if association.get("oneSchoolId") else None,
        "assigneeFound": None,
        "oneSchoolId": None,
        "tenantId": None,
        "schoolFound": None,
        "siteFound": None,
        "assignmentsCount": None,
    }

    log.info("STEP   branching on persona=%r", persona_lower)

    # Circuit Breaker: Individual Job Account persona short-circuits instantly
    if persona_lower == "individual":
        log.info("CIRCUIT BREAKER: persona='individual' -> Returning master profile only, zero school/site/assignments queries fired.")
        result["personaDescription"] = "Individual Job Account"
        result["isIndividual"] = True
        result["_debug"] = debug
        return result

    if persona_lower == "student":
        log.info("BRANCH student: querying assignees directly -> assignee name check -> batched assignments")
        assoc_school_id = association.get("oneSchoolId") or association.get("tenantId")
        exact_assoc_email = (association.get("userEmail") or email).strip()

        # Step 1: Query Rubix.assignees matching compound index (oneSchoolId + userEmail)
        if assoc_school_id:
            assignee_filt = {
                "oneSchoolId": assoc_school_id,
                "userEmail": exact_assoc_email,
            }
        else:
            assignee_filt = {
                "userEmail": exact_assoc_email,
            }

        q_started = _log_query("Rubix", "assignees", "find", assignee_filt)
        assignees = list(rubix["assignees"].find(assignee_filt))
        _log_result("Rubix", "assignees", q_started, len(assignees), label="assignee_match")

        # Fallback if specific oneSchoolId filter returned empty
        if not assignees and assoc_school_id:
            fallback_filt = {
                "userEmail": exact_assoc_email,
            }
            q_fb_started = _log_query("Rubix", "assignees", "find", fallback_filt)
            assignees = list(rubix["assignees"].find(fallback_filt))
            _log_result("Rubix", "assignees", q_fb_started, len(assignees), label="assignee_fallback")

        debug["assigneesCount"] = len(assignees)
        debug["assigneeFound"] = len(assignees) > 0
        log.info("STEP   assigneesFound=%s count=%d", debug["assigneeFound"], len(assignees))

        # Check if student name is present in assignees document directly
        if assignees:
            first = assignees[0].get("firstName") or assignees[0].get("first_name") or assignees[0].get("userFirstName")
            last = assignees[0].get("lastName") or assignees[0].get("last_name") or assignees[0].get("userLastName")
            if first or last:
                profile = {"firstName": first or "", "lastName": last or ""}
                log.info("STEP   student profile resolved directly from assignees document: firstName=%r lastName=%r", first, last)

        # Fallback to master_profiles if name was not present in assignees
        if not profile:
            profile = _fetch_master_profile()
        result["profile"] = profile

        combined_assignments = []
        resolved_school = None
        resolved_site = None
        resolved_sites = []

        if assignees:
            # Resolve School using the first assignee - a student's oneSchoolId
            # doesn't change across assignments, only the clinical site (tenant) does.
            one_school_id = assignees[0].get("oneSchoolId") or association.get("oneSchoolId")
            tenant_id = assignees[0].get("tenantId") or association.get("tenantId")

            if one_school_id:
                filt = {"_id": one_school_id}
                started = _log_query("Rubix", "tenant_schools", "find_one", filt)
                school_doc = rubix["tenant_schools"].find_one(filt)
                _log_result("Rubix", "tenant_schools", started, school_doc, label="school")
                resolved_school = _org_summary(school_doc, is_school=True)

            # Step 2: Single Batched Query for ALL assignments of ALL matched assignees.
            # Still filtered by assigneeId + oneSchoolId (keeps the compound index
            # usable) - but each assignee is paired with its OWN oneSchoolId instead
            # of reusing assignees[0]'s, so assignees from different schools each
            # still match correctly and none of their assignments get dropped.
            assignment_docs = []
            assignees_with_id = [a for a in assignees if "_id" in a]
            if assignees_with_id:
                if len(assignees_with_id) == 1:
                    a = assignees_with_id[0]
                    asnm_school_id = a.get("oneSchoolId") or association.get("oneSchoolId")
                    asnm_filt = {"assigneeId": a["_id"]}
                    if asnm_school_id:
                        asnm_filt["oneSchoolId"] = asnm_school_id
                else:
                    asnm_filt = {
                        "$or": [
                            {
                                "assigneeId": a["_id"],
                                **(
                                    {"oneSchoolId": a.get("oneSchoolId") or association.get("oneSchoolId")}
                                    if (a.get("oneSchoolId") or association.get("oneSchoolId"))
                                    else {}
                                ),
                            }
                            for a in assignees_with_id
                        ]
                    }

                q_asnm_started = _log_query("Rubix", "assignments", "find", asnm_filt)
                assignments_cursor = rubix["assignments"].find(asnm_filt)
                assignment_docs = list(assignments_cursor)
                _log_result("Rubix", "assignments", q_asnm_started, len(assignment_docs), label="batched_assignments")
                combined_assignments = [_assignment_summary(doc) for doc in assignment_docs]

            # Step 3: oneSchoolId is shared, but each assignment can sit at a
            # DIFFERENT clinical site (tenant). Collect every distinct tenantId
            # referenced by an assignee or an actual assignment document and
            # resolve them all in one batched query instead of only ever
            # showing the first assignee's site.
            seen_tenant_ids = set()
            all_tenant_ids = []

            def _collect_tenant_id(tid):
                if not tid:
                    return
                key = str(tid)
                if key not in seen_tenant_ids:
                    seen_tenant_ids.add(key)
                    all_tenant_ids.append(tid)

            for a in assignees:
                _collect_tenant_id(a.get("tenantId"))
            for doc in assignment_docs:
                _collect_tenant_id(doc.get("tenantId") or doc.get("siteId") or doc.get("tenantSiteId"))
            _collect_tenant_id(association.get("tenantId"))

            site_by_id = {}
            if all_tenant_ids:
                q_sites_started = _log_query("Rubix", "tenant_sites", "find", {"_id": {"$in": all_tenant_ids}})
                site_docs = list(rubix["tenant_sites"].find({"_id": {"$in": all_tenant_ids}}))
                _log_result("Rubix", "tenant_sites", q_sites_started, len(site_docs), label="student_sites")

                for s_doc in site_docs:
                    s_summary = _org_summary(s_doc)
                    site_by_id[str(s_doc.get("_id"))] = s_summary
                    resolved_sites.append(s_summary)

                resolved_site = site_by_id.get(str(tenant_id)) if tenant_id else (resolved_sites[0] if resolved_sites else None)

            # Let the frontend show which site each assignment actually belongs
            # to, instead of assuming they're all at the single "resolved" site.
            for asnm in combined_assignments:
                asnm["site"] = site_by_id.get(asnm.get("tenantId")) if asnm.get("tenantId") else None
        else:
            log.info("STEP   no assignees found for student -> skipping Rubix.assignments query")

        #school name dhundha hu !!!!
        if not resolved_school:
            school_id_fallback = association.get("oneSchoolId") or association.get("tenantId")
            if school_id_fallback:
                school_doc = rubix["tenant_schools"].find_one({"_id": school_id_fallback})
                resolved_school = _org_summary(school_doc, is_school=True)

        if not resolved_site and association.get("tenantId"):
            site_doc = rubix["tenant_sites"].find_one({"_id": association.get("tenantId")})
            resolved_site = _org_summary(site_doc)

        if not resolved_sites and resolved_site:
            resolved_sites = [resolved_site]

        result["school"] = resolved_school
        result["site"] = resolved_site
        result["sites"] = resolved_sites
        result["assignments"] = combined_assignments
        debug["assignmentsCount"] = len(combined_assignments)
        debug["sitesCount"] = len(resolved_sites)

    elif persona_lower in ("school", "school faculty"):
        log.info("BRANCH school: resolving tenant_schools from association.tenantId/oneSchoolId")
        one_school_id = association.get("tenantId") or association.get("oneSchoolId")
        debug["tenantId"] = str(one_school_id) if one_school_id else None
        if one_school_id:
            filt = {"_id": one_school_id}
            started = _log_query("Rubix", "tenant_schools", "find_one", filt)
            school_doc = rubix["tenant_schools"].find_one(filt)
            _log_result("Rubix", "tenant_schools", started, school_doc, label="school")
            debug["schoolFound"] = school_doc is not None
            result["school"] = _org_summary(school_doc, is_school=True)
        else:
            log.warning("BRANCH school: association has no tenantId/oneSchoolId - nothing to resolve")

    elif persona_lower == "site":
        log.info("BRANCH site: querying Rubix.profiles directly for name & roles -> tenant_sites")
        tenant_id = association.get("tenantId")
        debug["tenantId"] = str(tenant_id) if tenant_id else None

        exact_assoc_email = (association.get("userEmail") or email).strip()

        if tenant_id:
            prof_filt = {
                "tenantId": tenant_id,
                "userEmail": exact_assoc_email,
            }
        else:
            prof_filt = {
                "userEmail": exact_assoc_email,
            }

        q_prof_started = _log_query("Rubix", "profiles", "find_one", prof_filt)
        prof_doc = rubix["profiles"].find_one(prof_filt)
        _log_result("Rubix", "profiles", q_prof_started, prof_doc, label="rubix_profile")

        if not prof_doc and tenant_id:
            fallback_prof_filt = {"userEmail": exact_assoc_email}
            q_fb_started = _log_query("Rubix", "profiles", "find_one", fallback_prof_filt)
            prof_doc = rubix["profiles"].find_one(fallback_prof_filt)
            _log_result("Rubix", "profiles", q_fb_started, prof_doc, label="rubix_profile_fallback")

        if prof_doc:
            role_data = prof_doc.get("role") or prof_doc.get("roles") or {}
            roles_flags = {
                "isSiteAdmin": bool(role_data.get("isSiteAdmin", False)),
                "isJobsAdmin": bool(role_data.get("isJobsAdmin", False)),
                "locCoordinator": bool(role_data.get("locCoordinator", False)),
                "isPreceptor": bool(role_data.get("isPreceptor", False)),
                "dispCoordinator": bool(role_data.get("dispCoordinator", False)),
                "isReadOnly": bool(role_data.get("isReadOnly", False)),
            }
            profile = {
                "firstName": prof_doc.get("firstName") or prof_doc.get("first_name", ""),
                "lastName": prof_doc.get("lastName") or prof_doc.get("last_name", ""),
                "roles": roles_flags,
            }
            log.info("STEP   site profile & roles resolved directly from Rubix.profiles: firstName=%r lastName=%r roles=%r",
                     profile["firstName"], profile["lastName"], roles_flags)

        if not profile:
            profile = _fetch_master_profile()
        result["profile"] = profile

        if tenant_id:
            filt = {"_id": tenant_id}
            started = _log_query("Rubix", "tenant_sites", "find_one", filt)
            site_doc = rubix["tenant_sites"].find_one(filt)
            _log_result("Rubix", "tenant_sites", started, site_doc, label="site")
            debug["siteFound"] = site_doc is not None
            result["site"] = _org_summary(site_doc)
        else:
            log.warning("BRANCH site: association has no tenantId - nothing to resolve")

    else:
        log.warning("BRANCH none matched for persona=%r - returning skeleton result", persona)

    result["_debug"] = debug
    log.info("STEP   debug=%r", debug)
    log.info(
        "=== DONE _assemble_from_association email=%r persona=%r school=%s site=%s "
        "assignments=%d (%.1f ms) ===",
        email,
        persona,
        bool(result["school"]),
        bool(result["site"]),
        len(result["assignments"]),
        (time.perf_counter() - overall_started) * 1000,
    )
    return result


def lookup_email(email: str) -> dict:
    clean_email = (email or "").strip()
    log.info("### LOOKUP by email=%r ###", clean_email)
    if _is_exxat_email(clean_email):
        log.warning("REFUSED: lookup for @exxat.com email %r is not allowed.", clean_email)
        raise LookupError("Searching for @exxat.com internal emails is restricted.")

    started = time.perf_counter()
    client = get_client()
    exxat_network = client["ExxatNetwork"]

    raw_associations = _find_all_by_email(exxat_network["profile_associations"], clean_email)
    association_docs = [a for a in raw_associations if not _is_exxat_email(a.get("userEmail"))]
    if not association_docs:
        log.error("### LOOKUP FAILED: no valid profile_associations document for email=%r ###", clean_email)
        raise LookupError(f"No profile found for '{clean_email}'.")

    log.info("STEP   found %d profile_associations document(s) for email=%r", len(association_docs), clean_email)

    # Conflict detection: Check if multiple active Student persona associations exist for the email
    active_student_assocs = [
        a for a in association_docs
        if str(a.get("persona") or "").strip().lower() == "student" and bool(a.get("active", False))
    ]

    has_conflict = len(active_student_assocs) > 1
    conflict_message = None
    if has_conflict:
        conflict_message = (
            f"Profile association conflict: {len(active_student_assocs)} active Student "
            f"associations found for '{email}'. Students are typically associated with only one active school."
        )
        log.warning("### CONFLICT DETECTED: %s ###", conflict_message)

    resolved_associations = []
    for assoc in association_docs:
        resolved_associations.append(_assemble_from_association(assoc))

    # Construct unified payload returning all resolved associations
    out = {
        "email": email,
        "associationsCount": len(resolved_associations),
        "hasConflict": has_conflict,
        "conflictMessage": conflict_message,
        "associations": resolved_associations,
        # Backward compatibility properties (mapping to 1st association):
        "persona": resolved_associations[0]["persona"],
        "userActive": resolved_associations[0]["userActive"],
        "profile": resolved_associations[0]["profile"],
        "school": resolved_associations[0]["school"],
        "site": resolved_associations[0]["site"],
        "assignments": resolved_associations[0]["assignments"],
        "_debug": resolved_associations[0]["_debug"],
    }

    log.info(
        "### LOOKUP by email=%r complete (%d associations, conflict=%s, %.1f ms) ###",
        email,
        len(resolved_associations),
        has_conflict,
        (time.perf_counter() - started) * 1000,
    )
    return out


def lookup_by_association_id(id_str: str) -> dict:
    """Debug entrypoint: full resolution starting from a
    profile_associations _id instead of an email."""
    log.info("### LOOKUP by association _id=%r ###", id_str)
    started = time.perf_counter()
    client = get_client()
    try:
        oid = ObjectId(str(id_str).strip())
    except (InvalidId, TypeError, ValueError) as exc:
        log.error("STEP   invalid ObjectId %r (%s)", id_str, type(exc).__name__)
        raise LookupError(f"'{id_str}' is not a valid ObjectId.")

    log.debug("STEP   parsed ObjectId=%s", oid)
    filt = {"_id": oid, "_deleted": {"$ne": True}}
    q_started = _log_query("ExxatNetwork", "profile_associations", "find_one", filt)
    association = client["ExxatNetwork"]["profile_associations"].find_one(filt)
    _log_result("ExxatNetwork", "profile_associations", q_started, association, label="association")
    if not association:
        log.error("### LOOKUP FAILED: no profile_associations document with _id=%s ###", id_str)
        raise LookupError(f"No profile_associations document with _id={id_str}.")

    out = _assemble_from_association(association)
    log.info(
        "### LOOKUP by association _id=%r complete (%.1f ms) ###",
        id_str,
        (time.perf_counter() - started) * 1000,
    )
    return out


def search_school(query: str) -> dict:
    clean_q = query.strip()
    log.info("### SEARCH SCHOOL by query=%r ###", clean_q)
    started = time.perf_counter()
    client = get_client()
    rubix = client["Rubix"]
    exxat_network = client["ExxatNetwork"]

    school_doc = None
    if len(clean_q) == 24:
        try:
            oid = ObjectId(clean_q)
            school_doc = rubix["tenant_schools"].find_one({"_id": oid})
        except (InvalidId, TypeError, ValueError):
            pass

    if not school_doc:
        pattern = f'^"?.*{_escape(clean_q)}.*"?$'
        school_doc = rubix["tenant_schools"].find_one({"name": {"$regex": pattern, "$options": "i"}})

    if not school_doc:
        log.warning("### SEARCH SCHOOL FAILED: no tenant_schools document matching query=%r ###", clean_q)
        raise LookupError(f"No school found matching '{clean_q}'.")

    school_id = school_doc.get("_id")
    school_summary = _org_summary(school_doc, is_school=True)

    # Filter profile_associations for active School admins ONLY
    assoc_filt = {
        "$or": [{"tenantId": school_id}, {"oneSchoolId": school_id}],
        "persona": "School",
        "active": True,
        "_deleted": {"$ne": True},
    }
    q_assoc_started = _log_query("ExxatNetwork", "profile_associations", "find", assoc_filt)
    assocs = list(exxat_network["profile_associations"].find(assoc_filt))
    _log_result("ExxatNetwork", "profile_associations", q_assoc_started, len(assocs), label="admin_associations")

    # Collect profile IDs for a single batched $in query
    profile_ids = [a.get("oneProfileId") for a in assocs if a.get("oneProfileId")]
    master_profiles_by_id = {}
    if profile_ids:
        q_prof_started = _log_query("ExxatNetwork", "master_profiles", "find", {"_id": {"$in": profile_ids}})
        prof_docs = list(exxat_network["master_profiles"].find({"_id": {"$in": profile_ids}}))
        _log_result("ExxatNetwork", "master_profiles", q_prof_started, len(prof_docs), label="master_profile")
        for pd in prof_docs:
            master_profiles_by_id[pd["_id"]] = pd

    associated_profiles = []
    for assoc in assocs:
        email = (assoc.get("userEmail") or "").strip()
        if _is_exxat_email(email):
            continue
        raw_persona = str(assoc.get("persona") or "").strip()
        prof_id = assoc.get("oneProfileId")
        prof_doc = master_profiles_by_id.get(prof_id) or {}

        user_type = _get_user_type(assoc) or _get_user_type(prof_doc)
        if user_type.lower() in ("faculty", "school faculty"):
            persona_display = "School Faculty"
        elif raw_persona.lower() == "school":
            persona_display = "School Admin"
        else:
            persona_display = raw_persona

        associated_profiles.append({
            "_id": str(assoc.get("_id", "")),
            "email": email,
            "persona": persona_display,
            "userType": user_type,
            "firstName": prof_doc.get("firstName", ""),
            "lastName": prof_doc.get("lastName", ""),
            "active": True,
            "associationId": str(assoc.get("_id", "")),
        })

    partner_sites = _fetch_partner_sites_for_school(school_id)
    school_summary["partnerSites"] = partner_sites

    result = {
        "query": clean_q,
        "school": school_summary,
        "schoolId": str(school_id),
        "associatedProfiles": associated_profiles,
        "activeAdminsCount": len(associated_profiles),
        "partnerSites": partner_sites,
        "partnerSitesCount": len(partner_sites),
    }
    log.info("### SEARCH SCHOOL by query=%r complete (%d partners, %.1f ms) ###", clean_q, len(partner_sites), (time.perf_counter() - started) * 1000)
    return result


search_school_by_name = search_school


def search_site(query: str) -> dict:
    clean_q = query.strip()
    log.info("### SEARCH SITE by query=%r ###", clean_q)
    started = time.perf_counter()
    client = get_client()
    rubix = client["Rubix"]
    exxat_network = client["ExxatNetwork"]

    site_doc = None
    if len(clean_q) == 24:
        try:
            oid = ObjectId(clean_q)
            site_doc = rubix["tenant_sites"].find_one({"_id": oid})
        except (InvalidId, TypeError, ValueError):
            pass

    if not site_doc:
        pattern = f'^"?.*{_escape(clean_q)}.*"?$'
        site_doc = rubix["tenant_sites"].find_one({"name": {"$regex": pattern, "$options": "i"}})

    if not site_doc:
        log.warning("### SEARCH SITE FAILED: no tenant_sites document matching query=%r ###", clean_q)
        raise LookupError(f"No clinical site found matching '{clean_q}'.")

    site_id = site_doc.get("_id")
    site_summary = _org_summary(site_doc)

    # Filter profile_associations for active Site admins ONLY
    assoc_filt = {
        "tenantId": site_id,
        "persona": "Site",
        "active": True,
        "_deleted": {"$ne": True},
    }
    q_assoc_started = _log_query("ExxatNetwork", "profile_associations", "find", assoc_filt)
    assocs = list(exxat_network["profile_associations"].find(assoc_filt))
    _log_result("ExxatNetwork", "profile_associations", q_assoc_started, len(assocs), label="site_admin_associations")

    # Collect admin emails for a single batched $in query against Rubix.profiles
    admin_emails = []
    for a in assocs:
        e = (a.get("userEmail") or "").strip()
        if e:
            admin_emails.append(e)

    profiles_by_email = {}
    if admin_emails:
        import re
        regex_list = [re.compile(f"^{re.escape(em)}$", re.IGNORECASE) for em in admin_emails]
        q_prof_started = _log_query("Rubix", "profiles", "find", {"tenantId": site_id, "userEmail": {"$in": admin_emails}})
        prof_docs = list(rubix["profiles"].find({
            "tenantId": site_id,
            "userEmail": {"$in": regex_list}
        }))
        _log_result("Rubix", "profiles", q_prof_started, len(prof_docs), label="rubix_profile")
        for pd in prof_docs:
            em_key = (pd.get("userEmail") or "").strip().lower()
            if em_key:
                profiles_by_email[em_key] = pd

    associated_profiles = []
    for assoc in assocs:
        email = (assoc.get("userEmail") or "").strip()
        if _is_exxat_email(email):
            continue
        persona = str(assoc.get("persona") or "").strip()

        prof_doc = profiles_by_email.get(email.lower()) or {}
        role_data = prof_doc.get("role") or prof_doc.get("roles") or {}

        roles_flags = {
            "isSiteAdmin": bool(role_data.get("isSiteAdmin", False)),
            "isJobsAdmin": bool(role_data.get("isJobsAdmin", False)),
            "locCoordinator": bool(role_data.get("locCoordinator", False)),
            "isPreceptor": bool(role_data.get("isPreceptor", False)),
            "dispCoordinator": bool(role_data.get("dispCoordinator", False)),
            "isReadOnly": bool(role_data.get("isReadOnly", False)),
        }

        associated_profiles.append({
            "_id": str(assoc.get("_id", "")),
            "email": email,
            "persona": persona,
            "firstName": prof_doc.get("firstName") or prof_doc.get("first_name", ""),
            "lastName": prof_doc.get("lastName") or prof_doc.get("last_name", ""),
            "active": True,
            "associationId": str(assoc.get("_id", "")),
            "roles": roles_flags,
        })

    partner_schools = _fetch_partner_schools_for_site(site_id)
    site_summary["partnerSchools"] = partner_schools

    result = {
        "query": clean_q,
        "site": site_summary,
        "siteId": str(site_id),
        "associatedProfiles": associated_profiles,
        "activeUsersCount": len(associated_profiles),
        "partnerSchools": partner_schools,
        "partnerSchoolsCount": len(partner_schools),
    }
    log.info("### SEARCH SITE by query=%r complete (%d partners, %.1f ms) ###", clean_q, len(partner_schools), (time.perf_counter() - started) * 1000)
    return result


search_site_by_name = search_site


