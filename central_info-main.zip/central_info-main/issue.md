# School/Site Search — Performance RCA & Query Flow

## Questions being answered

1. Why is searching a school name in the School module taking so long (DevTools showed `Waiting for server response` of **6.9 min**, total load **13.6 min**)?
2. Why is searching a site by name also slow (DevTools showed `Waiting for server response` of **15.03 s** on a separate run)?
3. End-to-end: when a user types a name and hits Enter, how does that query actually get sent to the database, and how does it find the school/site **plus** its associated profiles?
4. Are there any Mongo **joins / `$lookup` / aggregation pipelines** involved in that resolution?

---

## 1. How a search request actually flows (current implementation)

### 1.1 Frontend (browser)

[static/js/app.js:285-298](static/js/app.js#L285-L298) — pressing **Enter** in the search box (or clicking the search button) calls `runModuleSearch(query)`.

[static/js/app.js:300-346](static/js/app.js#L300-L346) — `runModuleSearch`:
- First checks an **in-memory client-side cache** (`state.history[currentTab]`) for a prior identical query (case-insensitive match). If found, it's rendered instantly with **zero network request**.
- Otherwise it disables the input/button and fires exactly **one** `fetch()`:
- School tab → `GET /api/search/school?q=<query>`
- Site tab → `GET /api/search/site?q=<query>`
- It `await`s the full JSON response before re-enabling the input. There is no debounce, no cancellation of an in-flight request, and no client-side timeout — the browser will wait as long as the server takes, which is exactly what the Network tab captured (`Waiting for server response` = however long the Python/Mongo side took).

So: **one keystroke (Enter) → one HTTP request → the browser just waits.** The multi-minute duration you saw in DevTools is 100% server-side/database-side time, not a frontend problem.

### 1.2 Backend route

[app.py:189-214](app.py#L189-L214) (school) and [app.py:216-240](app.py#L216-L240) (site):
- Read `q` (or `name`) from the query string.
- Ensure a Mongo client exists (`db_service.get_client()`), reconnecting via `test_connection` if needed.
- Call `db_service.search_school(query)` / `db_service.search_site(query)`.
- Wrap the result in `{"ok": true, "data": ...}` and return it as JSON.

This is a single Flask request handler — **no background job, no streaming, no pagination**. The HTTP response isn't sent until the entire Python function below has finished running.

### 1.3 Database resolution — `search_school()` / `search_site()`

[db_service.py:597-671](db_service.py#L597-L671) (school) and [db_service.py:677-751](db_service.py#L677-L751) (site) — both follow the identical pattern:

**Step A — find the org document:**
```
if len(query) == 24: # looks like an ObjectId
 try: find_one({_id: ObjectId(query)})
if not found:
 pattern = '^"?.*<escaped query>.*"?$'
 find_one({"name": {"$regex": pattern, "$options": "i"}}) # <-- the actual "search by name" path
```

**Step B — find every profile linked to that org:**
```
# School:
find({"$or": [{"tenantId": school_id}, {"oneSchoolId": school_id}], "_deleted": {"$ne": True}})
# Site:
find({"tenantId": site_id, "_deleted": {"$ne": True}})
```
This returns a **cursor over `ExxatNetwork.profile_associations`** — every student/faculty/admin association tied to that school or site.

**Step C — for every single association returned in Step B, if it has a profile id, run one more query:**
```python
for assoc in assoc_cursor: # could be dozens/hundreds/thousands of docs
 ...
 if prof_id:
 prof_doc = exxat_network["master_profiles"].find_one({"_id": prof_id}) # <-- ONE query per person
```
([db_service.py:641-647](db_service.py#L641-L647) school, [db_service.py:721-727](db_service.py#L721-L727) site.)

### Answering your direct question: **are there any joins / `$lookup` / aggregation pipelines?**

**No.** There is not a single `aggregate()` call or `$lookup` stage anywhere in `db_service.py`. Every "join" in this app is done **manually, in Python, as separate sequential round-trips to MongoDB**:

- 1 query → resolve the school/site by regex on `name`
- 1 query → get the cursor of associated `profile_associations`
-**N queries** → one `find_one` against `master_profiles` per association, executed one-by-one inside a Python `for` loop

So for a school with, say, 400 active students/faculty, a single "search by name" click issues **1 (school) + 1 (associations, one cursor) + 400 (profile lookups) = 402 separate MongoDB round trips**, all sequential, all on the same request thread.

---

## 2. Why it's slow — root causes

### 2.1 Leading-wildcard, case-insensitive regex on `name` (biggest single factor for Step A)

```python
pattern = f'^"?.*{_escape(clean_q)}.*"?$'
find_one({"name": {"$regex": pattern, "$options": "i"}})
```
[db_service.py:614-615](db_service.py#L614-L615) / [db_service.py:694-695](db_service.py#L694-L695)

- The pattern starts with `.*` (leading wildcard) and uses case-insensitive matching (`$options: "i"`).
- MongoDB **cannot use a B-tree index** for a regex that doesn't anchor to a literal prefix, and case-insensitivity defeats even prefix-anchored index usage.
- Result: every `search_school`/`search_site` call is a **full collection scan (`COLLSCAN`)** of `tenant_schools` / `tenant_sites`, with the regex evaluated document-by-document inside `mongod`, until the *first* match is found (`find_one`). On a large, shared, multi-tenant collection this alone can take anywhere from tens of milliseconds to several seconds depending on cluster load and where in the collection the match sits (worst case: no match, or the match is near the end → the whole collection gets scanned).

### 2.2 N+1 query pattern for associated profiles (biggest factor for the multi-minute cases)

Step C above is the real story behind a **6.9-minute** response: if that school has hundreds of associations, the server makes hundreds of **sequential** `find_one` calls to `ExxatNetwork.master_profiles`, each one paying:
- Full network round-trip latency to the Mongo Atlas cluster (this environment has already shown symptoms of a slow/unstable path to Atlas — see the earlier `ERR_CONNECTION_RESET` investigation).
- No connection pooling benefit beyond avoiding a new TCP handshake — it's still one full request/response cycle per document, per user.

Even at a "healthy" 50-100ms per round trip, 400 profiles = 20-40 seconds just for Step C. Over a congested corporate VPN/firewall path to Atlas (RTT spikes into hundreds of ms or requires retries), this easily stretches into **minutes**, matching what you saw.

### 2.3 Unbounded result set

Neither `search_school` nor `search_site` apply a `.limit()` to the `profile_associations` cursor. Every matching association is fetched and then, per §2.2, triggers its own profile lookup. There is no cap on how large this can grow.

### 2.4 No `maxTimeMS` on any query

None of the `find`/`find_one` calls set `maxTimeMS`. A slow scan or slow round trip is not bounded by the query itself — it's only bounded by pymongo's `socketTimeoutMS=45000` ([db_service.py:111](db_service.py#L111)) *per socket operation*, not per logical request. Since Step C is hundreds of *separate* operations, none of which individually exceeds 45s, the *overall* request can run far longer than any single timeout would suggest — nothing kills a search that is just "slow but technically succeeding one call at a time."

### 2.5 Single-threaded dev server compounds it for concurrent users

`app.run(host="127.0.0.1", port=5050, debug=True, use_reloader=True)` ([app.py:245](app.py#L245)) does not pass `threaded=True`. Werkzeug's dev server defaults to handling **one request at a time**. If a slow school/site search (or a slow `/api/lookup`) is in flight, every other request — including your own next click, or another teammate's request if this were ever shared — queues behind it until it finishes. This wouldn't explain a *single* request being slow on its own, but it does explain why unrelated requests around the same time (e.g., the favicon 404, `/api/config/status` polling) can appear to stall in the Network tab.

### 2.6 Site search additionally counts *every* active user, not just admins

Minor, not a perf driver by itself, but worth noting: `search_site` increments `active_users_count` for any active persona ([db_service.py:717-719](db_service.py#L717-L719)), while `search_school` only counts active `school`-persona users ([db_service.py:637-639](db_service.py#L637-L639)) — asymmetric logic, unrelated to the timing issue but easy to mistake for a bug while reading this code.

---

## 3. Reading the Network tab timings you pasted

-**Queueing / Stalled / DNS Lookup / Initial connection**: sub-millisecond in both your traces — the browser-to-Flask hop (`127.0.0.1:5050`) is instant, as expected for localhost.
-**Request sent**: sub-millisecond — trivial GET with a query string.
-**Waiting for server response (TTFB)**: **6.9 min** and **15.03 s** respectively — this is the entire time Flask spent inside `search_school`/`search_site`, i.e., §2.1 + §2.2 + §2.3 + §2.4 combined. This is where 100% of the problem lives.
-**Content Download**: ~2ms / ~0.36ms — trivial, the JSON payload itself is small and fast to transfer once ready.

In short: the browser did nothing wrong and there's nothing to fix client-side. The entire delay is the backend performing an unindexed regex scan followed by an unbounded, one-row-at-a-time N+1 join in Python instead of a single aggregation query.

---

## 4. Where a fix would target (for a future change, not implemented here)

Not applying any code changes per your request — just noting where the leverage is, for when you're ready:

1. Replace the per-profile `find_one` loop (§2.2) with a single `$lookup` aggregation from `profile_associations` into `master_profiles` — turns N+1 round trips into 1.
2. Add an index-friendly search strategy for `name` (e.g., a MongoDB **text index** with `$text`, or at minimum an anchored/prefix regex `^query` with a supporting index) instead of the unanchored, case-insensitive `.*query.*` regex.
3. Add `.limit()`/pagination to the associations cursor, and consider projecting only the fields actually rendered (`firstName`, `lastName`, `email`, `persona`, `active`) instead of full documents.
4. Set an explicit `maxTimeMS` on the school/site lookup and the associations query so a pathological scan fails fast with a clear error instead of hanging.
5. Consider `threaded=True` (or a real WSGI server) so one slow search doesn't block every other request on this Flask process.