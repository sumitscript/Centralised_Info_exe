"""Secure local storage for the MongoDB connection string.

The encrypted connection string is stored locally in `.config.enc` in the project directory.
Encryption uses Fernet symmetric encryption with a key derived from the local machine's unique ID.
"""
import base64
import hashlib
import os
import winreg
import sys
from cryptography.fernet import Fernet, InvalidToken

if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG_PATH = os.path.join(BASE_DIR, ".config.enc")


def _machine_guid() -> str:
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
        guid, _ = winreg.QueryValueEx(key, "MachineGuid")
        winreg.CloseKey(key)
        return guid
    except OSError:
        return "centralised-info-local-key"


def _fernet() -> Fernet:
    digest = hashlib.sha256(_machine_guid().encode("utf-8")).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


def save_uri(uri: str) -> None:
    token = _fernet().encrypt(uri.encode("utf-8"))
    with open(CONFIG_PATH, "wb") as f:
        f.write(token)


ENV_PATH = os.path.join(BASE_DIR, ".env")


def _read_env_file() -> str | None:
    if os.path.exists(ENV_PATH):
        try:
            with open(ENV_PATH, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        k, v = k.strip(), v.strip().strip("'").strip('"')
                        if k in ("MONGODB_URI", "MONGO_URI") and v:
                            return v
        except OSError:
            pass
    return None


def load_uri() -> str | None:
    if not os.path.exists(CONFIG_PATH):
        env_uri = os.environ.get("MONGODB_URI") or os.environ.get("MONGO_URI") or _read_env_file()
        if env_uri:
            try:
                save_uri(env_uri)
                return env_uri
            except OSError:
                return env_uri
        return None
    try:
        with open(CONFIG_PATH, "rb") as f:
            token = f.read()
        return _fernet().decrypt(token).decode("utf-8")
    except (InvalidToken, ValueError, OSError):
        return None


def clear_uri() -> None:
    if os.path.exists(CONFIG_PATH):
        os.remove(CONFIG_PATH)


def mask_uri(uri: str) -> str:
    """mongodb+srv://user:****@cluster/... for safe display."""
    if "@" not in uri:
        return uri
    scheme_and_creds, rest = uri.rsplit("@", 1)
    if "://" not in scheme_and_creds:
        return uri
    scheme, creds = scheme_and_creds.split("://", 1)
    user = creds.split(":", 1)[0] if ":" in creds else creds
    return f"{scheme}://{user}:****@{rest}"
