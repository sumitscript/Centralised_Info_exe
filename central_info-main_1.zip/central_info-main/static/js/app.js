// URL Routing Engine for Dynamic Deep-Link Anchors
const UrlEngine = {
  KEY: "central_info_url_tpls",
  defaults: {
    school: "https://example.com/dashboard/{schoolId}/dashboard",
    site: "https://example.com/site/{siteId}/dashboard",
    assignment: "https://example.com/assignment/{siteId}-{assignmentId}"
  },
  getTemplates() {
    try {
      const stored = localStorage.getItem(this.KEY);
      if (stored) return { ...this.defaults, ...JSON.parse(stored) };
    } catch (e) {}
    return { ...this.defaults };
  },
  saveTemplates(tpls) {
    try {
      localStorage.setItem(this.KEY, JSON.stringify(tpls));
    } catch (e) {}
  },
  buildSchoolUrl(schoolId) {
    if (!schoolId) return "#";
    const tpls = this.getTemplates();
    return (tpls.school || this.defaults.school).replace(/\{schoolId\}/g, encodeURIComponent(schoolId));
  },
  buildSiteUrl(siteId) {
    if (!siteId) return "#";
    const tpls = this.getTemplates();
    return (tpls.site || this.defaults.site).replace(/\{siteId\}/g, encodeURIComponent(siteId));
  },
  buildAssignmentUrl(siteId, assignmentId) {
    if (!assignmentId) return "#";
    const tpls = this.getTemplates();
    const safeSiteId = siteId || "site";
    return (tpls.assignment || this.defaults.assignment)
      .replace(/\{siteId\}/g, encodeURIComponent(safeSiteId))
      .replace(/\{assignmentId\}/g, encodeURIComponent(assignmentId));
  }
};

// Clipboard Helper
async function copyToClipboard(text, btnEl) {
  if (!text) return;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    if (btnEl) {
      const originalText = btnEl.innerHTML;
      btnEl.innerHTML = "Copied!";
      btnEl.style.borderColor = "var(--success)";
      btnEl.style.color = "var(--success)";
      setTimeout(() => {
        btnEl.innerHTML = originalText;
        btnEl.style.borderColor = "";
        btnEl.style.color = "";
      }, 1200);
    }
  } catch (err) {
    console.error("Copy failed:", err);
  }
}

// Inline Status Indicator Renderer (Matching Screenshot: ● Active)
function getStatusIndicatorHtml(active, labelActive = "Active", labelInactive = "Inactive") {
  const isOk = !!active;
  return `
    <span class="status-indicator ${isOk ? "ok" : "bad"}">
      <span class="status-dot-icon"></span>
      <span>${isOk ? labelActive : labelInactive}</span>
    </span>
  `;
}

const state = {
  activeTab: "email", // "email" | "school" | "site"
  history: {
    email: [],
    school: [],
    site: [],
    displayid: []
  },
  activeQuery: {
    email: null,
    school: null,
    site: null,
    displayid: null
  },
  configured: false
};

const el = (id) => document.getElementById(id);

// UI Element Handles
const connDot = el("connDot");
const connDotTop = el("connDotTop");
const connText = el("connText");
const searchInput = el("searchInput");
const searchBtn = el("searchBtn");
const statusBanner = el("statusBanner");

const sidebarHistoryList = el("sidebarHistoryList");
const historyTabLabel = el("historyTabLabel");
const clearHistoryBtn = el("clearHistoryBtn");
const settingsBtn = el("settingsBtn");

const tabEmail = el("tabEmail");
const tabSchool = el("tabSchool");
const tabSite = el("tabSite");
const tabDisplayId = el("tabDisplayId");

const emailView = el("emailView");
const schoolView = el("schoolView");
const siteView = el("siteView");
const displayidView = el("displayidView");

const configBackdrop = el("configBackdrop");
const uriInput = el("uriInput");
const urlTplSchool = el("urlTplSchool");
const urlTplSite = el("urlTplSite");
const urlTplAssignment = el("urlTplAssignment");
const modalMsg = el("modalMsg");
const saveConfigBtn = el("saveConfigBtn");
const cancelConfigBtn = el("cancelConfigBtn");
const clearConfigBtn = el("clearConfigBtn");

// Connection Status Management
function setConnState(mode, label) {
  const dotClass = "dot" + (mode ? ` ${mode}` : "");
  if (connDot) connDot.className = dotClass;
  if (connDotTop) connDotTop.className = dotClass;
  if (connText) connText.textContent = label;
}

async function refreshConnStatus() {
  setConnState("pending", "Checking…");
  try {
    const res = await fetch("/api/config/status");
    const data = await res.json();
    state.configured = !!data.configured;
    if (!data.configured) {
      setConnState("", "Not connected");
    } else if (data.connected) {
      setConnState("ok", "Connected");
    } else {
      setConnState("", data.message || "Connection failed");
    }
  } catch {
    state.configured = false;
    setConnState("", "Not connected");
  }
  updateClearButtonVisibility();
}

function updateClearButtonVisibility() {
  clearConfigBtn.style.display = state.configured ? "" : "none";
}

function showModal() {
  modalMsg.textContent = "";
  modalMsg.className = "modal-msg";
  if (state.configured) {
    uriInput.value = "••••••••••••••••••••••••";
  } else {
    uriInput.value = "";
  }

  const tpls = UrlEngine.getTemplates();
  if (urlTplSchool) urlTplSchool.value = tpls.school;
  if (urlTplSite) urlTplSite.value = tpls.site;
  if (urlTplAssignment) urlTplAssignment.value = tpls.assignment;

  updateClearButtonVisibility();
  configBackdrop.classList.remove("hidden");
  uriInput.focus();
}
function hideModal() {
  configBackdrop.classList.add("hidden");
}

settingsBtn.addEventListener("click", showModal);
cancelConfigBtn.addEventListener("click", hideModal);
configBackdrop.addEventListener("click", (e) => {
  if (e.target === configBackdrop) hideModal();
});

saveConfigBtn.addEventListener("click", async () => {
  UrlEngine.saveTemplates({
    school: urlTplSchool.value.trim() || UrlEngine.defaults.school,
    site: urlTplSite.value.trim() || UrlEngine.defaults.site,
    assignment: urlTplAssignment.value.trim() || UrlEngine.defaults.assignment
  });

  const uri = uriInput.value.trim();
  if (uri) {
    saveConfigBtn.textContent = "Testing…";
    saveConfigBtn.disabled = true;
    try {
      const res = await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uri }),
      });
      const data = await res.json();
      if (data.ok) {
        modalMsg.textContent = "Connected & settings saved.";
        modalMsg.className = "modal-msg ok";
        await refreshConnStatus();
        setTimeout(hideModal, 700);
      } else {
        modalMsg.textContent = data.message || "Connection failed.";
        modalMsg.className = "modal-msg bad";
      }
    } catch (err) {
      modalMsg.textContent = "Request failed: " + err;
      modalMsg.className = "modal-msg bad";
    } finally {
      saveConfigBtn.textContent = "Save & Apply";
      saveConfigBtn.disabled = false;
    }
  } else {
    modalMsg.textContent = "Routing templates saved.";
    modalMsg.className = "modal-msg ok";
    setTimeout(hideModal, 600);
  }
});

clearConfigBtn.addEventListener("click", async () => {
  await fetch("/api/config", { method: "DELETE" });
  await refreshConnStatus();
  hideModal();
});

function showBanner(message) {
  statusBanner.textContent = message;
  statusBanner.classList.remove("hidden");
}
function hideBanner() {
  statusBanner.classList.add("hidden");
}

// Tab Switching & Context Management
const TAB_CONFIGS = {
  email: {
    label: "Email",
    placeholder: "Enter email address and press Enter…",
    view: emailView,
    btn: tabEmail
  },
  school: {
    label: "School",
    placeholder: "Enter school name or ObjectId and press Enter… (e.g. St. Jude)",
    view: schoolView,
    btn: tabSchool
  },
  site: {
    label: "Clinical Site",
    placeholder: "Enter clinical site name or ObjectId and press Enter… (e.g. Mercy)",
    view: siteView,
    btn: tabSite
  },
  displayid: {
    label: "Display ID",
    placeholder: "Enter assignment Display ID and press Enter…",
    view: displayidView,
    btn: tabDisplayId
  }
};

function switchTab(tabKey) {
  if (!TAB_CONFIGS[tabKey]) return;
  state.activeTab = tabKey;

  Object.keys(TAB_CONFIGS).forEach((k) => {
    TAB_CONFIGS[k].btn.classList.toggle("active", k === tabKey);
    TAB_CONFIGS[k].view.classList.toggle("hidden", k !== tabKey);
  });

  searchInput.placeholder = TAB_CONFIGS[tabKey].placeholder;
  searchInput.value = state.activeQuery[tabKey] || "";

  historyTabLabel.textContent = TAB_CONFIGS[tabKey].label;
  renderSidebarHistory();
  hideBanner();
}

tabEmail.addEventListener("click", () => switchTab("email"));
tabSchool.addEventListener("click", () => switchTab("school"));
tabSite.addEventListener("click", () => switchTab("site"));
tabDisplayId.addEventListener("click", () => switchTab("displayid"));

// Search Triggering & Execution
searchInput.addEventListener("keydown", async (e) => {
  if (e.key !== "Enter") return;
  const query = searchInput.value.trim();
  if (!query) return;
  await runModuleSearch(query);
});

if (searchBtn) {
  searchBtn.addEventListener("click", async () => {
    const query = searchInput.value.trim();
    if (!query) return;
    await runModuleSearch(query);
  });
}

async function runModuleSearch(query) {
  hideBanner();
  const currentTab = state.activeTab;
  const globalLoader = document.getElementById("globalLoader");
  const currentView = TAB_CONFIGS[currentTab] ? TAB_CONFIGS[currentTab].view : null;

  if (currentTab === "email" && query.trim().toLowerCase().endsWith("@exxat.com")) {
    showBanner("Searching for @exxat.com internal emails is restricted.", "warn");
    return;
  }

  const tabHistory = state.history[currentTab];

  const cached = tabHistory.find((h) => h.query.toLowerCase() === query.toLowerCase());
  if (cached) {
    state.activeQuery[currentTab] = query;
    if (globalLoader) globalLoader.classList.add("hidden");
    if (currentView) currentView.classList.remove("hidden");
    renderModuleData(currentTab, cached.data);
    renderSidebarHistory();
    return;
  }

  searchInput.disabled = true;
  if (searchBtn) searchBtn.disabled = true;
  if (globalLoader) globalLoader.classList.remove("hidden");
  if (currentView) currentView.classList.add("hidden");

  try {
    let endpoint = "";
    if (currentTab === "email") {
      endpoint = `/api/lookup?email=${encodeURIComponent(query)}`;
    } else if (currentTab === "school") {
      endpoint = `/api/search/school?q=${encodeURIComponent(query)}`;
    } else if (currentTab === "site") {
      endpoint = `/api/search/site?q=${encodeURIComponent(query)}`;
    } else if (currentTab === "displayid") {
      endpoint = `/api/search/displayid?q=${encodeURIComponent(query)}`;
    }

    const res = await fetch(endpoint);
    const data = await res.json();

    if (!data.ok) {
      showBanner(data.message || `Lookup failed for ${currentTab}.`);
      return;
    }

    tabHistory.unshift({ query, data: data.data });
    state.activeQuery[currentTab] = query;

    renderModuleData(currentTab, data.data);
    renderSidebarHistory();
  } catch (err) {
    showBanner("Request failed: " + err);
  } finally {
    searchInput.disabled = false;
    if (searchBtn) searchBtn.disabled = false;
    if (globalLoader) globalLoader.classList.add("hidden");
    if (currentView) currentView.classList.remove("hidden");
    searchInput.focus();
  }
}

function renderModuleData(tabKey, data) {
  if (tabKey === "email") {
    renderResult(data);
  } else if (tabKey === "school") {
    renderSchoolModuleResult(data);
  } else if (tabKey === "site") {
    renderSiteModuleResult(data);
  } else if (tabKey === "displayid") {
    renderDisplayIdModuleResult(data);
  }
}

// Sidebar History Renderer
function renderSidebarHistory() {
  sidebarHistoryList.innerHTML = "";
  const tabHistory = state.history[state.activeTab];
  const activeQuery = state.activeQuery[state.activeTab];

  if (!tabHistory.length) {
    sidebarHistoryList.innerHTML = `<p class="sidebar-empty">No recent searches for this module.</p>`;
    return;
  }

  tabHistory.forEach((h) => {
    const item = document.createElement("div");
    const isActive = activeQuery && h.query.toLowerCase() === activeQuery.toLowerCase();
    item.className = "sidebar-history-item" + (isActive ? " active" : "");

    let subtitle = "";
    if (state.activeTab === "email" && h.data) {
      const count = h.data.associationsCount || (h.data.associations ? h.data.associations.length : 1);
      subtitle = `${h.data.persona || "User"} · ${count} Association(s)${h.data.hasConflict ? " · Conflict" : ""}`;
    } else if (state.activeTab === "school" && h.data) {
      subtitle = `${h.data.associatedProfiles ? h.data.associatedProfiles.length : 0} Profiles linked`;
    } else if (state.activeTab === "site" && h.data) {
      subtitle = `${h.data.associatedProfiles ? h.data.associatedProfiles.length : 0} Users linked`;
    } else if (state.activeTab === "displayid" && h.data) {
      subtitle = `${h.data.student ? (h.data.student.firstName + " " + h.data.student.lastName).trim() : ""}${h.data.isGroupPlacement ? " · Group Placement" : ""}`;
    }

    item.innerHTML = `
      <span class="sidebar-item-query">${escapeHtml(h.query)}</span>
      <span class="sidebar-item-sub">${escapeHtml(subtitle)}</span>
    `;

    item.addEventListener("click", () => {
      searchInput.value = h.query;
      state.activeQuery[state.activeTab] = h.query;
      renderModuleData(state.activeTab, h.data);
      renderSidebarHistory();
    });

    sidebarHistoryList.appendChild(item);
  });
}

clearHistoryBtn.addEventListener("click", () => {
  state.history[state.activeTab] = [];
  state.activeQuery[state.activeTab] = null;
  renderSidebarHistory();
  hideBanner();
});

// Collapsible List Toggle Helper
function toggleCollapsible(btn, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const isHidden = container.classList.contains("hidden");
  const count = btn.getAttribute("data-count") || "";
  if (isHidden) {
    container.classList.remove("hidden");
    btn.innerHTML = `See Less`;
  } else {
    container.classList.add("hidden");
    btn.innerHTML = `See More (+${count} more)`;
  }
}

function renderContactsListHtml(contacts, searchEmail = null, idPrefix = "poc") {
  if (!contacts || !contacts.length) {
    return `<p class="empty-hint">No POC contacts listed.</p>`;
  }

  const cleanSearch = (searchEmail || "").trim().toLowerCase();

  const renderContactRow = (c) => {
    const isMatch = cleanSearch && c.email && c.email.trim().toLowerCase() === cleanSearch;
    return `
      <div class="contact-row ${isMatch ? "poc-highlight" : ""}">
        <span class="contact-name">${escapeHtml(c.firstName)} ${escapeHtml(c.lastName)}</span>
        <span class="contact-meta">${escapeHtml(c.email)}${c.type ? " · " + escapeHtml(c.type) : ""}</span>
      </div>
    `;
  };

  if (contacts.length <= 5) {
    return contacts.map(renderContactRow).join("");
  }

  const visibleContacts = contacts.slice(0, 5).map(renderContactRow).join("");
  const extraContacts = contacts.slice(5).map(renderContactRow).join("");
  const extraId = idPrefix + "_" + Math.random().toString(36).substr(2, 9);
  const extraCount = contacts.length - 5;

  return `
    ${visibleContacts}
    <div class="collapsible-extra hidden" id="${extraId}">${extraContacts}</div>
    <button class="btn-see-more" data-count="${extraCount}" onclick="toggleCollapsible(this, '${extraId}')">See More (+${extraCount} more)</button>
  `;
}

// Render View 1: Email Search Result
function renderResult(data) {
  if (data.hasConflict && data.conflictMessage) {
    showBanner(data.conflictMessage);
  } else {
    hideBanner();
  }

  const associations = data.associations || [data];
  const emailViewContainer = el("emailView");

  let htmlContent = "";

  associations.forEach((assoc, idx) => {
    const assocTitle = associations.length > 1
      ? `ASSOCIATION #${idx + 1}: ${assoc.persona || "USER"} ${assoc.school ? "— " + escapeHtml(assoc.school.name) : ""}`
      : null;

    const userActiveBadge = getStatusIndicatorHtml(assoc.userActive, "User Active", "User Inactive");
    const searchEmail = data.email || assoc.email || "";

    const isIndividual = (assoc.persona || "").toLowerCase() === "individual" || assoc.isIndividual;
    const personaLabel = isIndividual ? "Individual" : (assoc.persona || "—");
    const individualAccountBadge = isIndividual ? `<div class="individual-account-tag">Individual Job Account</div>` : "";

    let profileContent = `<p class="empty-hint">Profile not found.</p><div style="margin-top:10px;">${userActiveBadge}</div>`;
    if (assoc.profile) {
      let roleBadgesHtml = "";
      if (assoc.profile.roles) {
        const roles = assoc.profile.roles || {};
        const roleTags = [];
        if (roles.isSiteAdmin) roleTags.push("Site Admin");
        if (roles.isJobsAdmin) roleTags.push("Job Admin");
        if (roles.locCoordinator) roleTags.push("Location Coord");
        if (roles.isPreceptor) roleTags.push("Preceptor");
        if (roles.dispCoordinator) roleTags.push("Disp Coordinator");
        if (roles.isReadOnly) roleTags.push("Read Only");
        if (roleTags.length) {
          roleBadgesHtml = `<div class="badge-row" style="margin-top:8px;">${roleTags.map(r => `<span class="role-badge">${escapeHtml(r)}</span>`).join("")}</div>`;
        }
      }

      profileContent = `
        <div class="profile-name">${escapeHtml(assoc.profile.firstName)} ${escapeHtml(assoc.profile.lastName)}</div>
        <div class="profile-email">${escapeHtml(searchEmail)}</div>
        ${individualAccountBadge}
        ${roleBadgesHtml}
        <div style="margin-top:10px;">${userActiveBadge}</div>
      `;
    }

    let schoolContent = getOrgCardHtml(assoc.school, "school", searchEmail);

    // A student's assignments can span multiple different clinical sites
    // (tenants) even though they share one school - render one Site block
    // per distinct site instead of only ever showing assoc.site.
    const sites = (assoc.sites && assoc.sites.length) ? assoc.sites : (assoc.site ? [assoc.site] : []);
    let siteContent;
    if (!sites.length) {
      siteContent = getOrgCardHtml(null, "site", searchEmail);
    } else if (sites.length === 1) {
      siteContent = getOrgCardHtml(sites[0], "site", searchEmail);
    } else {
      siteContent = sites.map((s, i) => {
        const sId = s._id || s.id;
        return `
          <div class="section-title" style="margin-top:${i === 0 ? "0" : "16px"}; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center; gap:8px;">
            <span>Site ${i + 1}${s.name ? ": " + escapeHtml(s.name) : ""}</span>
            ${sId ? `
              <div style="display:flex; gap:6px;">
                <button class="btn-copy-id" onclick="copyToClipboard('${sId}', this)" title="Copy Site ID">Copy ID</button>
                <a href="${UrlEngine.buildSiteUrl(sId)}" target="_blank" class="btn-link-arrow" title="Open Site Dashboard">↗</a>
              </div>
            ` : ""}
          </div>
          ${getOrgCardHtml(s, "site", searchEmail)}
          ${i < sites.length - 1 ? `<div style="border-top:1px dashed var(--border); margin-top:14px;"></div>` : ""}
        `;
      }).join("");
    }

    let assignmentsHtml = "";
    if (assoc.assignments && assoc.assignments.length) {
      // Fallback only - each assignment carries its own tenantId (the site it was
      // actually made against), which getAssignmentCardHtml prefers over this.
      const fallbackSiteId = assoc.site ? (assoc.site._id || assoc.site.id) : null;
      assignmentsHtml = `
        <section class="assignments-section">
          <h2 class="section-title">Assignments (${assoc.assignments.length})</h2>
          <div class="assignments-list">
            ${assoc.assignments.map((a) => getAssignmentCardHtml(a, fallbackSiteId)).join("")}
          </div>
        </section>
      `;
    }

    htmlContent += `
      <div class="association-block" style="${idx > 0 ? "margin-top:24px; padding-top:20px; border-top:1px dashed var(--border);" : ""}">
        ${assocTitle ? `<h3 class="section-title" style="color:var(--text); font-size:11px; margin-bottom:12px;">${assocTitle}</h3>` : ""}
        <section class="cards-grid">
          <article class="card">
            <header class="card-head">
              <span class="card-title">Profile</span>
              <span class="persona-badge">${escapeHtml(personaLabel)}</span>
            </header>
            <div class="card-body">${profileContent}</div>
          </article>

          <article class="card">
            <header class="card-head">
              <span class="card-title">School</span>
              ${assoc.school && (assoc.school._id || assoc.school.id) ? `
                <div style="display:flex; gap:6px; align-items:center;">
                  <button class="btn-copy-id" onclick="copyToClipboard('${assoc.school._id || assoc.school.id}', this)" title="Copy School ID">Copy ID</button>
                  <a href="${UrlEngine.buildSchoolUrl(assoc.school._id || assoc.school.id)}" target="_blank" class="btn-link-arrow" title="Open School Dashboard">↗</a>
                </div>
              ` : ""}
            </header>
            <div class="card-body">${schoolContent}</div>
          </article>

          <article class="card">
            <header class="card-head">
              <span class="card-title">Site${sites.length > 1 ? ` (${sites.length})` : ""}</span>
              ${sites.length === 1 && (sites[0]._id || sites[0].id) ? `
                <div style="display:flex; gap:6px; align-items:center;">
                  <button class="btn-copy-id" onclick="copyToClipboard('${sites[0]._id || sites[0].id}', this)" title="Copy Site ID">Copy ID</button>
                  <a href="${UrlEngine.buildSiteUrl(sites[0]._id || sites[0].id)}" target="_blank" class="btn-link-arrow" title="Open Site Dashboard">↗</a>
                </div>
              ` : ""}
            </header>
            <div class="card-body">${siteContent}</div>
          </article>
        </section>
        ${assignmentsHtml}
      </div>
    `;
  });

  if (data.hasMore) {
    const remaining = (data.associationsCount || 0) - associations.length;
    htmlContent += `
      <div style="text-align:center; margin-top:20px;">
        <button id="loadMoreAssociationsBtn" class="btn-see-more" onclick="loadMoreAssociations()">Load More Associations (${remaining} more)</button>
      </div>
    `;
  }

  emailViewContainer.innerHTML = htmlContent;
}

async function loadMoreAssociations() {
  const currentTab = state.activeTab;
  const query = state.activeQuery[currentTab];
  const tabHistory = state.history[currentTab];
  const entry = tabHistory.find((h) => h.query.toLowerCase() === (query || "").toLowerCase());
  if (!entry || !entry.data) return;
  const data = entry.data;
  const nextOffset = (data.offset || 0) + (data.associations ? data.associations.length : 0);

  const btn = document.getElementById("loadMoreAssociationsBtn");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Loading...";
  }

  try {
    const res = await fetch(`/api/lookup?email=${encodeURIComponent(data.email)}&offset=${nextOffset}`);
    const resp = await res.json();
    if (!resp.ok) {
      showBanner(resp.message || "Failed to load more associations.");
      return;
    }

    data.associations = (data.associations || []).concat(resp.data.associations || []);
    data.offset = resp.data.offset;
    data.limit = resp.data.limit;
    data.hasMore = resp.data.hasMore;
    data.associationsCount = resp.data.associationsCount;

    renderResult(data);
  } catch (err) {
    showBanner("Request failed: " + err);
  }
}

function renderPartnerListHtml(partners, kind = "site", idPrefix = "partner") {
  if (!partners || !partners.length) {
    return `<p class="empty-hint">No partnered ${kind === "site" ? "clinical sites" : "schools"} on record.</p>`;
  }

  const renderPartnerItem = (p) => {
    const pId = p._id || p.id;
    const url = kind === "site" ? UrlEngine.buildSiteUrl(pId) : UrlEngine.buildSchoolUrl(pId);
    const activeBadge = getStatusIndicatorHtml(p.active, "Active", "Inactive");
    const prismBadge = kind === "school" ? getPrismTagHtml(p.prismTag) : "";
    const addressHtml = p.address ? `
      <div class="org-address" style="margin-top:2px; margin-bottom:4px;">
        <svg class="location-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        <span>${escapeHtml(p.address)}</span>
      </div>
    ` : "";

    return `
      <div class="associated-item">
        <div class="user-info" style="flex:1;">
          <span class="user-name-line" style="font-size:13px; font-weight:600;">${escapeHtml(p.name)}</span>
          ${addressHtml}
        </div>
        <div class="badge-row">
          ${activeBadge}
          ${prismBadge}
          ${pId ? `
            <button class="btn-copy-id" onclick="copyToClipboard('${pId}', this)" title="Copy ID">Copy ID</button>
            <a href="${url}" target="_blank" class="btn-link-arrow" title="Open Dashboard">↗</a>
          ` : ""}
        </div>
      </div>
    `;
  };

  if (partners.length <= 5) {
    return `<div class="associated-list">${partners.map(renderPartnerItem).join("")}</div>`;
  }

  const visiblePartners = partners.slice(0, 5).map(renderPartnerItem).join("");
  const extraPartners = partners.slice(5).map(renderPartnerItem).join("");
  const extraId = idPrefix + "_" + Math.random().toString(36).substr(2, 9);
  const extraCount = partners.length - 5;

  return `
    <div class="associated-list">
      ${visiblePartners}
      <div class="collapsible-extra hidden" id="${extraId}">${extraPartners}</div>
      <button class="btn-see-more" data-count="${extraCount}" onclick="toggleCollapsible(this, '${extraId}')">See More (+${extraCount} more)</button>
    </div>
  `;
}

function getPrismTagHtml(prismTag) {
  if (!prismTag) return "";
  const isPrism = prismTag === "Prism";
  return `<span class="prism-tag ${isPrism ? "is-prism" : "is-no-prism"}">${escapeHtml(prismTag)}</span>`;
}

function getOrgCardHtml(org, kind, searchEmail = null) {
  if (!org) return `<p class="empty-hint">No ${kind} on record.</p>`;

  const kindLabel = kind.charAt(0).toUpperCase() + kind.slice(1);
  const prismBadge = kind === "school" ? getPrismTagHtml(org.prismTag) : "";
  const activeBadge = `<div class="badge-row" style="margin-bottom:8px;">${getStatusIndicatorHtml(org.active, kindLabel + " Active", kindLabel + " Inactive")}${prismBadge}</div>`;

  const addressHtml = org.address ? `
    <div class="org-address">
      <svg class="location-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
      <span>${escapeHtml(org.address)}</span>
    </div>
  ` : "";

  const contactsHtml = renderContactsListHtml(org.contacts, searchEmail, kind + "_poc");

  let partnerHtml = "";
  if (kind === "school" && org.partnerSites && org.partnerSites.length) {
    partnerHtml = `
      <div class="section-title" style="margin-top:14px; margin-bottom:8px;">Partnered Clinical Sites (${org.partnerSites.length})</div>
      ${renderPartnerListHtml(org.partnerSites, "site", "school_card_partners")}
    `;
  } else if (kind === "site" && org.partnerSchools && org.partnerSchools.length) {
    partnerHtml = `
      <div class="section-title" style="margin-top:14px; margin-bottom:8px;">Partnered Schools (${org.partnerSchools.length})</div>
      ${renderPartnerListHtml(org.partnerSchools, "school", "site_card_partners")}
    `;
  }

  return `
    <div class="org-name-row">
      <span class="org-name">${escapeHtml(org.name)}</span>
    </div>
    ${addressHtml}
    ${activeBadge}
    ${contactsHtml}
    ${partnerHtml}
  `;
}

function getAssignmentCardHtml(a, fallbackSiteId) {
  const asnmId = a.id || a._id;
  const asnmUrl = UrlEngine.buildAssignmentUrl(a.tenantId || fallbackSiteId, asnmId);

  const availHtml = (a.availabilities || [])
    .map((av) => `<span class="avail-chip${av.active ? "" : " inactive"}">${escapeHtml(av.name)}</span>`)
    .join("");

  // Each assignment can be at a different clinical site - label it so it's
  // clear which site this specific card (and its dashboard link) belongs to.
  const siteLabelHtml = a.site && a.site.name
    ? `<span class="role-badge" title="Clinical site for this assignment">${escapeHtml(a.site.name)}</span>`
    : "";
  const assignmentTypeHtml = a.assignmentType
    ? `<span class="role-badge">${escapeHtml(a.assignmentType)}</span>`
    : "";

  return `
    <div class="assignment-card">
      <div class="assignment-top">
        <div class="badge-row">
          ${siteLabelHtml}
          ${assignmentTypeHtml}
          ${getStatusIndicatorHtml(a.studentConfirmed, "Student Confirmed", "Not Confirmed")}
          ${getStatusIndicatorHtml(a.paymentDone, "Payment Done", a.payStatus || "Payment Pending")}
          ${getStatusIndicatorHtml(a.onboarding.compliant, "Onboarding Compliant", "Onboarding Non-Compliant")}
          ${getStatusIndicatorHtml(a.offboarding.compliant, "Offboarding Compliant", "Offboarding Non-Compliant")}
          ${getStatusIndicatorHtml(a.caas.compliant, "CAAS Compliant", "CAAS Non-Compliant")}
        </div>

        <div style="display:flex; gap:8px; align-items:center;">
          <div class="assignment-dates">${a.startDate || "—"} → ${a.endDate || "—"}</div>
          ${a.displayId ? `
            <button class="btn-copy-id" onclick="copyToClipboard('${a.displayId}', this)" title="Copy Display ID (${a.displayId})">Copy Display ID</button>
          ` : ""}
          ${asnmId ? `
            <button class="btn-copy-id" onclick="copyToClipboard('${asnmId}', this)" title="Copy Assignment ID">Copy ID</button>
            <a href="${asnmUrl}" target="_blank" class="btn-link-arrow" title="Open Assignment Dashboard">↗</a>
          ` : ""}
        </div>
      </div>
      <div class="availability-list">${availHtml}</div>
    </div>
  `;
}

// Render View 2: School Search Result (Dual ID or Name Search Output)
function renderSchoolModuleResult(data) {
  const school = data.school;
  const statusBadge = el("schoolModuleStatusBadge");
  const detailsBody = el("schoolModuleDetailsBody");
  const partnersCountBadge = el("schoolModulePartnersCount");
  const partnersBody = el("schoolModulePartnersBody");
  const countBadge = el("schoolModuleProfilesCount");
  const profilesBody = el("schoolModuleProfilesBody");

  if (!school) {
    statusBadge.innerHTML = getStatusIndicatorHtml(false, "School Active", "School Inactive");
    detailsBody.innerHTML = `<p class="empty-hint">No school details found.</p>`;
    if (partnersCountBadge) partnersCountBadge.textContent = "0 Sites";
    if (partnersBody) partnersBody.innerHTML = `<p class="empty-hint">No partnered sites found.</p>`;
    countBadge.textContent = "0 Users";
    profilesBody.innerHTML = `<p class="empty-hint">No associated profiles found.</p>`;
    return;
  }

  const schoolId = school._id || school.id || data.schoolId;
  statusBadge.innerHTML = getStatusIndicatorHtml(school.active, "School Active", "School Inactive") + getPrismTagHtml(school.prismTag);

  const addressHtml = school.address ? `
    <div class="org-address">
      <svg class="location-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
      <span>${escapeHtml(school.address)}</span>
    </div>
  ` : "";

  const contactsHtml = renderContactsListHtml(school.contacts, null, "school_module_poc");

  detailsBody.innerHTML = `
    <div class="org-name-row">
      <span class="org-name">${escapeHtml(school.name)}</span>
      ${schoolId ? `
        <div style="display:flex; gap:6px; align-items:center;">
          <button class="btn-copy-id" onclick="copyToClipboard('${schoolId}', this)" title="Copy School ID">Copy ID</button>
          <a href="${UrlEngine.buildSchoolUrl(schoolId)}" target="_blank" class="btn-link-arrow" title="Open School Dashboard">↗</a>
        </div>
      ` : ""}
    </div>
    ${addressHtml}
    <div class="section-title" style="margin-top:12px; margin-bottom:8px;">POC Contacts</div>
    ${contactsHtml}
  `;

  // Render Partnered Sites
  const partnerSites = data.partnerSites || (school ? school.partnerSites : []) || [];
  if (partnersCountBadge) partnersCountBadge.textContent = `${partnerSites.length} Sites`;
  if (partnersBody) {
    partnersBody.innerHTML = renderPartnerListHtml(partnerSites, "site", "school_module_partners");
  }

  const profiles = data.associatedProfiles || [];
  countBadge.textContent = `${profiles.length} Associated Admins / Faculty`;

  if (!profiles.length) {
    profilesBody.innerHTML = `<p class="empty-hint">No active admins or faculty associated with this school.</p>`;
    return;
  }

  const renderProfileItem = (p) => `
    <div class="associated-item">
      <div class="user-info">
        <span class="user-name-line">${escapeHtml(p.firstName || "Unnamed")} ${escapeHtml(p.lastName || "Admin")}</span>
        <span class="user-email-line">${escapeHtml(p.email || "No email")}</span>
      </div>
      <div class="badge-row">
        <span class="persona-badge">School Admin</span>
        ${getStatusIndicatorHtml(p.active, "Active", "Inactive")}
        ${p._id ? `<button class="btn-copy-id" onclick="copyToClipboard('${p._id}', this)" title="Copy Profile Association ID">Copy ID</button>` : ""}
      </div>
    </div>
  `;

  let profilesListHtml = "";
  if (profiles.length <= 5) {
    profilesListHtml = profiles.map(renderProfileItem).join("");
  } else {
    const visibleProfiles = profiles.slice(0, 5).map(renderProfileItem).join("");
    const extraProfiles = profiles.slice(5).map(renderProfileItem).join("");
    const extraId = "school_profiles_" + Math.random().toString(36).substr(2, 9);
    const extraCount = profiles.length - 5;
    profilesListHtml = `
      ${visibleProfiles}
      <div class="collapsible-extra hidden" id="${extraId}">${extraProfiles}</div>
      <button class="btn-see-more" data-count="${extraCount}" onclick="toggleCollapsible(this, '${extraId}')">See More (+${extraCount} more)</button>
    `;
  }

  profilesBody.innerHTML = `<div class="associated-list">${profilesListHtml}</div>`;
}

// Render View 3: Site Search Result (Dual ID or Name Search Output)
function renderSiteModuleResult(data) {
  const site = data.site;
  const statusBadge = el("siteModuleStatusBadge");
  const detailsBody = el("siteModuleDetailsBody");
  const partnersCountBadge = el("siteModulePartnersCount");
  const partnersBody = el("siteModulePartnersBody");
  const countBadge = el("siteModuleProfilesCount");
  const profilesBody = el("siteModuleProfilesBody");

  if (!site) {
    statusBadge.innerHTML = getStatusIndicatorHtml(false, "Site Active", "Site Inactive");
    detailsBody.innerHTML = `<p class="empty-hint">No clinical site details found.</p>`;
    if (partnersCountBadge) partnersCountBadge.textContent = "0 Schools";
    if (partnersBody) partnersBody.innerHTML = `<p class="empty-hint">No partnered schools found.</p>`;
    countBadge.textContent = "0 Admins";
    profilesBody.innerHTML = `<p class="empty-hint">No associated site admins found.</p>`;
    return;
  }

  const siteId = site._id || site.id || data.siteId;
  statusBadge.innerHTML = getStatusIndicatorHtml(site.active, "Site Active", "Site Inactive");

  const addressHtml = site.address ? `
    <div class="org-address">
      <svg class="location-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
      <span>${escapeHtml(site.address)}</span>
    </div>
  ` : "";

  const contactsHtml = renderContactsListHtml(site.contacts, null, "site_module_poc");

  detailsBody.innerHTML = `
    <div class="org-name-row">
      <span class="org-name">${escapeHtml(site.name)}</span>
      ${siteId ? `
        <div style="display:flex; gap:6px; align-items:center;">
          <button class="btn-copy-id" onclick="copyToClipboard('${siteId}', this)" title="Copy Site ID">Copy ID</button>
          <a href="${UrlEngine.buildSiteUrl(siteId)}" target="_blank" class="btn-link-arrow" title="Open Site Dashboard">↗</a>
        </div>
      ` : ""}
    </div>
    ${addressHtml}
    <div class="section-title" style="margin-top:12px; margin-bottom:8px;">POC Contacts</div>
    ${contactsHtml}
  `;

  // Render Partnered Schools
  const partnerSchools = data.partnerSchools || (site ? site.partnerSchools : []) || [];
  if (partnersCountBadge) partnersCountBadge.textContent = `${partnerSchools.length} Schools`;
  if (partnersBody) {
    partnersBody.innerHTML = renderPartnerListHtml(partnerSchools, "school", "site_module_partners");
  }

  const profiles = data.associatedProfiles || [];
  countBadge.textContent = `${profiles.length} Active Site Admins`;

  if (!profiles.length) {
    profilesBody.innerHTML = `<p class="empty-hint">No active site admins found for this site.</p>`;
    return;
  }

  const renderSiteProfileItem = (p) => {
    const roles = p.roles || {};
    const roleTags = [];
    if (roles.isSiteAdmin) roleTags.push("Site Admin");
    if (roles.isJobsAdmin) roleTags.push("Job Admin");
    if (roles.locCoordinator) roleTags.push("Location Coord");
    if (roles.isPreceptor) roleTags.push("Preceptor");
    if (roles.dispCoordinator) roleTags.push("Coordinator");
    if (roles.isReadOnly) roleTags.push("Read Only");

    const roleBadgesHtml = roleTags.length
      ? roleTags.map(r => `<span class="role-badge">${escapeHtml(r)}</span>`).join("")
      : `<span class="persona-badge">Site Admin</span>`;

    return `
      <div class="associated-item">
        <div class="user-info">
          <span class="user-name-line">${escapeHtml(p.firstName || "Unnamed")} ${escapeHtml(p.lastName || "Admin")}</span>
          <span class="user-email-line">${escapeHtml(p.email || "No email")}</span>
        </div>
        <div class="badge-row">
          ${roleBadgesHtml}
          ${getStatusIndicatorHtml(p.active, "Active", "Inactive")}
          ${p._id ? `<button class="btn-copy-id" onclick="copyToClipboard('${p._id}', this)" title="Copy Profile Association ID">Copy ID</button>` : ""}
        </div>
      </div>
    `;
  };

  let profilesListHtml = "";
  if (profiles.length <= 5) {
    profilesListHtml = profiles.map(renderSiteProfileItem).join("");
  } else {
    const visibleProfiles = profiles.slice(0, 5).map(renderSiteProfileItem).join("");
    const extraProfiles = profiles.slice(5).map(renderSiteProfileItem).join("");
    const extraId = "site_profiles_" + Math.random().toString(36).substr(2, 9);
    const extraCount = profiles.length - 5;
    profilesListHtml = `
      ${visibleProfiles}
      <div class="collapsible-extra hidden" id="${extraId}">${extraProfiles}</div>
      <button class="btn-see-more" data-count="${extraCount}" onclick="toggleCollapsible(this, '${extraId}')">See More (+${extraCount} more)</button>
    `;
  }

  profilesBody.innerHTML = `<div class="associated-list">${profilesListHtml}</div>`;
}

function getDisplayIdAssignmentCardHtml(a) {
  const siteId = a.site ? (a.site._id || a.site.id) : null;
  const asnmUrl = UrlEngine.buildAssignmentUrl(siteId, a.id);

  const availHtml = (a.availabilities || [])
    .map((av) => `<span class="avail-chip${av.active ? "" : " inactive"}">${escapeHtml(av.name)}</span>`)
    .join("");

  const siteLabelHtml = a.site && a.site.name
    ? `<span class="role-badge" title="Clinical site for this assignment">${escapeHtml(a.site.name)}</span>`
    : "";
  const locationLabelHtml = a.locationName
    ? `<span class="role-badge" title="Placement location">${escapeHtml(a.locationName)}</span>`
    : "";
  const assignmentTypeHtml = `<span class="role-badge">${a.isGroupPlacement ? "Group Placement" : "Individual Placement"}</span>`;
  const groupNameHtml = a.isGroupPlacement && a.groupName
    ? `<span class="role-badge" title="Group name">${escapeHtml(a.groupName)}</span>`
    : "";
  const preceptorNames = (a.faculties || [])
    .map((f) => `${f.firstName || ""} ${f.lastName || ""}`.trim())
    .filter(Boolean)
    .join(", ");
  const preceptorHtml = preceptorNames
    ? `<span class="role-badge" title="Preceptor">Preceptor: ${escapeHtml(preceptorNames)}</span>`
    : "";

  return `
    <div class="assignment-card">
      <div class="assignment-top">
        <div class="badge-row">
          ${siteLabelHtml}
          ${locationLabelHtml}
          ${assignmentTypeHtml}
          ${groupNameHtml}
          ${preceptorHtml}
          ${getStatusIndicatorHtml(a.studentConfirmed, "Student Confirmed", "Not Confirmed")}
          ${getStatusIndicatorHtml(a.paymentDone, "Payment Done", a.payStatus || "Payment Pending")}
          ${getStatusIndicatorHtml(a.onboardingCompliant, "Onboarding Compliant", "Onboarding Non-Compliant")}
          ${getStatusIndicatorHtml(a.offboardingCompliant, "Offboarding Compliant", "Offboarding Non-Compliant")}
          ${getStatusIndicatorHtml(a.ongoingCompliant, "Ongoing Compliant", "Ongoing Non-Compliant")}
        </div>

        <div style="display:flex; gap:8px; align-items:center; margin-left:auto; flex-wrap:wrap; justify-content:flex-end;">
          <div class="assignment-dates">${a.startDate || "—"} → ${a.endDate || "—"}</div>
          ${a.displayId ? `
            <button class="btn-copy-id" onclick="copyToClipboard('${a.displayId}', this)" title="Copy Display ID (${a.displayId})">Copy Display ID</button>
          ` : ""}
          ${a.id ? `
            <button class="btn-copy-id" onclick="copyToClipboard('${a.id}', this)" title="Copy Assignment ID">Copy ID</button>
            <a href="${asnmUrl}" target="_blank" class="btn-link-arrow" title="Open Assignment Dashboard">↗</a>
          ` : ""}
        </div>
      </div>
      <div class="availability-list">${availHtml}</div>
    </div>
  `;
}

// Render View 4: Display ID Search Result (assignments_mv)
function renderDisplayIdModuleResult(data) {
  const placementBadge = el("displayIdPlacementBadge");
  const profileBody = el("displayIdProfileBody");
  const schoolBody = el("displayIdSchoolBody");
  const siteBody = el("displayIdSiteBody");
  const assignmentsList = el("displayIdAssignmentsList");
  const preceptorBody = el("displayIdPreceptorBody");

  if (!data) {
    placementBadge.textContent = "—";
    profileBody.innerHTML = `<p class="empty-hint">No assignment found.</p>`;
    schoolBody.innerHTML = `<p class="empty-hint">—</p>`;
    siteBody.innerHTML = `<p class="empty-hint">—</p>`;
    assignmentsList.innerHTML = "";
    preceptorBody.innerHTML = `<p class="empty-hint">—</p>`;
    return;
  }

  placementBadge.textContent = "Student";

  const student = data.student || {};
  const studentName = `${student.firstName || ""} ${student.lastName || ""}`.trim() || "Unnamed Student";

  profileBody.innerHTML = `
    <div class="profile-name">${escapeHtml(studentName)}</div>
    <div class="profile-email">${escapeHtml(student.email || "")}</div>
  `;

  assignmentsList.innerHTML = getDisplayIdAssignmentCardHtml(data);

  const school = data.school;
  if (!school || (!school.name && !school.address && !(school.contacts || []).length)) {
    schoolBody.innerHTML = `<p class="empty-hint">No school on record.</p>`;
  } else {
    const activeBadge = school.active === null || school.active === undefined
      ? ""
      : `<div class="badge-row" style="margin-bottom:8px;">${getStatusIndicatorHtml(school.active, "School Active", "School Inactive")}${getPrismTagHtml(school.prismTag)}</div>`;
    const addressHtml = school.address ? `
      <div class="org-address">
        <svg class="location-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        <span>${escapeHtml(school.address)}</span>
      </div>
    ` : "";
    schoolBody.innerHTML = `
      <div class="org-name-row">
        <span class="org-name">${escapeHtml(school.name)}</span>
        ${school._id ? `
          <div style="display:flex; gap:6px; align-items:center;">
            <button class="btn-copy-id" onclick="copyToClipboard('${school._id}', this)" title="Copy School ID">Copy ID</button>
            <a href="${UrlEngine.buildSchoolUrl(school._id)}" target="_blank" class="btn-link-arrow" title="Open School Dashboard">↗</a>
          </div>
        ` : ""}
      </div>
      ${activeBadge}
      ${addressHtml}
      <div class="section-title" style="margin-top:12px; margin-bottom:8px;">POC Contacts</div>
      ${renderContactsListHtml(school.contacts, student.email, "displayid_school_poc")}
    `;
  }

  const site = data.site;
  if (!site || (!site.name && !site.address && !(site.contacts || []).length)) {
    siteBody.innerHTML = `<p class="empty-hint">No clinical site on record.</p>`;
  } else {
    const activeBadge = site.active === null || site.active === undefined
      ? ""
      : `<div class="badge-row" style="margin-bottom:8px;">${getStatusIndicatorHtml(site.active, "Site Active", "Site Inactive")}</div>`;
    const addressHtml = site.address ? `
      <div class="org-address">
        <svg class="location-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        <span>${escapeHtml(site.address)}</span>
      </div>
    ` : "";
    siteBody.innerHTML = `
      <div class="org-name-row">
        <span class="org-name">${escapeHtml(site.name)}</span>
        ${site._id ? `
          <div style="display:flex; gap:6px; align-items:center;">
            <button class="btn-copy-id" onclick="copyToClipboard('${site._id}', this)" title="Copy Site ID">Copy ID</button>
            <a href="${UrlEngine.buildSiteUrl(site._id)}" target="_blank" class="btn-link-arrow" title="Open Site Dashboard">↗</a>
          </div>
        ` : ""}
      </div>
      ${activeBadge}
      ${addressHtml}
      <div class="section-title" style="margin-top:12px; margin-bottom:8px;">POC Contacts</div>
      ${renderContactsListHtml(site.contacts, student.email, "displayid_site_poc")}
    `;
  }

  const faculties = data.faculties || [];
  if (!faculties.length) {
    preceptorBody.innerHTML = `<p class="empty-hint">No preceptor / faculty on record.</p>`;
  } else {
    preceptorBody.innerHTML = `
      <div class="associated-list">
        ${faculties.map((f) => `
          <div class="associated-item">
            <div class="user-info">
              <span class="user-name-line">${escapeHtml(f.firstName)} ${escapeHtml(f.lastName)}</span>
              <span class="user-email-line">${escapeHtml(f.email)}</span>
            </div>
          </div>
        `).join("")}
      </div>
    `;
  }
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// Initial Connection Check
refreshConnStatus();

