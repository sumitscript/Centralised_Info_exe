"""Generic Mongo-query capture/instrumentation utility.

Wrap every document or list a query returns with `track(collection, value)`
right after fetching it, then keep using the RETURNED value exactly as you
would the raw one - .get(), [], iteration all still behave identically, but
every read is now recorded. At the end of a top-level lookup, call
`flush_captures()` once: it writes one JSON file per tracked query into
`returnedvalue/`, describing the document's structure (field names/types
only - actual values are NEVER written) and tagging every field
`_used: true/false` depending on whether downstream code in that lookup
actually read it, vs. a field Mongo returned that nothing ever consumed.

Filenames are `<collection>.json`, or `<collection>_1.json`,
`<collection>_2.json`, ... if that collection was queried more than once
in the same lookup (e.g. a fallback query re-hitting the same collection).
"""

import json
import os


class _UsageTracker:
    __slots__ = ("used_paths",)

    def __init__(self):
        self.used_paths = set()

    def mark(self, path: tuple) -> None:
        self.used_paths.add(path)


class TrackingDict(dict):
    """Behaves like a plain dict everywhere, but .get()/[] reads are
    recorded against the tracker so the field can be tagged 'used' later."""

    def __init__(self, data, tracker, path=()):
        super().__init__(data)
        self._tracker = tracker
        self._path = path

    def get(self, key, default=None):
        if dict.__contains__(self, key):
            child_path = self._path + (key,)
            self._tracker.mark(child_path)
            return _wrap(dict.__getitem__(self, key), self._tracker, child_path)
        return default

    def __getitem__(self, key):
        child_path = self._path + (key,)
        self._tracker.mark(child_path)
        return _wrap(dict.__getitem__(self, key), self._tracker, child_path)


class TrackingList(list):
    """List items funnel through a single '[*]' path segment rather than a
    per-index one - what matters for the capture is whether a field is EVER
    read across the items, not whether index 3 specifically was."""

    def __init__(self, data, tracker, path=()):
        super().__init__(data)
        self._tracker = tracker
        self._path = path

    def __getitem__(self, index):
        if isinstance(index, slice):
            return list.__getitem__(self, index)
        value = list.__getitem__(self, index)
        item_path = self._path + ("[*]",)
        self._tracker.mark(item_path)
        return _wrap(value, self._tracker, item_path)

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]


def _wrap(value, tracker, path):
    if isinstance(value, (TrackingDict, TrackingList)):
        return value
    if isinstance(value, dict):
        return TrackingDict(value, tracker, path)
    if isinstance(value, list):
        return TrackingList(value, tracker, path)
    return value


_pending = []  # [(collection, raw_value, tracker), ...] queued since the last flush


def track(collection: str, value):
    """Wrap a just-fetched Mongo document/list/None for usage tracking and
    queue it for the next flush_captures() call. Always use the RETURNED
    value in place of the raw one from here on - e.g.
    `doc = track("tenant_schools", doc)`."""
    tracker = _UsageTracker()
    _pending.append((collection, value, tracker))
    if value is None:
        return None
    return _wrap(value, tracker, ())


def _shape(value, tracker, path):
    if isinstance(value, dict):
        return {
            "_type": "object",
            "_used": path == () or path in tracker.used_paths,
            "_fields": {str(k): _shape(v, tracker, path + (k,)) for k, v in value.items()},
        }
    if isinstance(value, list):
        item_shape = _shape(value[0], tracker, path + ("[*]",)) if value else None
        return {
            "_type": "array",
            "_used": path == () or path in tracker.used_paths,
            "_length": len(value),
            "_item_shape": item_shape,
        }
    return {
        "_type": type(value).__name__ if value is not None else "null",
        "_used": path == () or path in tracker.used_paths,
    }


def _capture_folder() -> str:
    folder = os.path.join(os.getcwd(), "returnedvalue")
    os.makedirs(folder, exist_ok=True)
    return folder


def _unique_filename(folder: str, collection: str) -> str:
    base = f"{collection}.json"
    if not os.path.exists(os.path.join(folder, base)):
        return base
    n = 1
    while os.path.exists(os.path.join(folder, f"{collection}_{n}.json")):
        n += 1
    return f"{collection}_{n}.json"


def flush_captures():
    """Write every query tracked since the last flush to returnedvalue/,
    one file per query (never actual field values, tags only), then clear
    the queue. Returns the list of file paths written."""
    folder = _capture_folder()
    written = []
    for collection, raw_value, tracker in _pending:
        shape = {"_type": "null", "_used": True} if raw_value is None else _shape(raw_value, tracker, ())
        filename = _unique_filename(folder, collection)
        path = os.path.join(folder, filename)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(shape, fh, indent=2)
        written.append(path)
    _pending.clear()
    return written
