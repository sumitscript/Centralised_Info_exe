# MongoDB Indexes Reference (`INDEX_USED.md`)

This document lists all database indexes utilized by the **Centralised Info** application to ensure fast response times across all lookups, searches, and persona resolutions.

---

## Overview of Database Queries & Indexes

The application queries two MongoDB databases:
- **`ExxatNetwork`**: Manages master profiles and user persona associations.
- **`Rubix`**: Manages assignee data, school/site tenant metadata, assignments, and site admin profiles.

---

## 1. Database: `ExxatNetwork`

### 1.1 Collection: `profile_associations`

Used during every lookup to map an entered email to a persona, profile ID, school ID, or site tenant ID, as well as finding active school and site administrators.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "userEmail": 1, "_deleted": 1 }` | Compound | Email search in `_find_all_by_email()` |
| `{ "tenantId": 1, "persona": 1, "active": 1, "_deleted": 1 }` | Compound | Admin filtering in `search_school()` and `search_site()` |
| `{ "oneSchoolId": 1, "persona": 1, "active": 1, "_deleted": 1 }` | Compound | School admin filtering in `search_school()` |
| `{ "_id": 1 }` | Single Field (Default) | Direct lookup in `lookup_by_association_id()` |

### 1.2 Collection: `master_profiles`

Used to fetch user names (`firstName`, `lastName`) for resolved profile IDs.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "_id": 1 }` | Single Field (Default) | Primary profile lookup by `oneProfileId` or batch `$in` query |

---

## 2. Database: `Rubix`

### 2.1 Collection: `assignees`

Used for Student persona resolutions to map student emails to assignee IDs, school IDs, and site tenant IDs.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "oneSchoolId": 1, "userEmail": 1 }` | Compound | Instant Student assignee matching by school ID + student email |

### 2.2 Collection: `tenant_schools`

Used to fetch school details and search schools by name or ID.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "_id": 1 }` | Single Field (Default) | School lookup by `oneSchoolId` |
| `{ "name": 1 }` | Single Field | Regex search in `search_school()` |

### 2.3 Collection: `tenant_sites`

Used to fetch site details and search clinical sites by name or ID.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "_id": 1 }` | Single Field (Default) | Site lookup by `tenantId` |
| `{ "name": 1 }` | Single Field | Regex search in `search_site()` |

### 2.4 Collection: `assignments`

Used to fetch student assignment records (compliance, offboarding, onboarding, CAAS).

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "assigneeId": 1 }` | Single Field | Assignment lookup for a student assignee |

### 2.5 Collection: `profiles`

Used during clinical site searches (`search_site`) to map site admin emails to roles and names.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "tenantId": 1, "userEmail": 1 }` | Compound | Batch site admin lookup in `search_site()` |

### 2.6 Collection: `assignments_mv`

Used by the Display ID search (`lookup_display_id`) - a denormalized materialized view of an assignment carrying school/site names, assignee, location, policy and compliance fields inline, so a single lookup avoids the multi-collection Student persona resolution.

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "displayId": 1, "_deleted": 1 }` | Compound | Display ID search in `lookup_display_id()` |

### 2.7 Collection: `partners`

Used to resolve school-site partnerships (`_fetch_partner_sites_for_school` and `_fetch_partner_schools_for_site`).

| Index Key | Index Type | Purpose / Query Target |
|---|---|---|
| `{ "oneSchoolId": 1, "_deleted": 1 }` | Compound | Fetch partnered sites for a school |
| `{ "tenantId": 1, "_deleted": 1 }` | Compound | Fetch partnered schools for a clinical site |

---

## Automated Setup Scripts

### MongoDB Shell (`mongosh`) Script

Copy and execute the following script in `mongosh` to create all required indexes:

```js
// --- Database: ExxatNetwork ---
use ExxatNetwork;

db.profile_associations.createIndex({ userEmail: 1, _deleted: 1 });
db.profile_associations.createIndex({ tenantId: 1, persona: 1, active: 1, _deleted: 1 });
db.profile_associations.createIndex({ oneSchoolId: 1, persona: 1, active: 1, _deleted: 1 });

// --- Database: Rubix ---
use Rubix;

db.assignees.createIndex({ userEmail: 1, _deleted: 1 });
db.tenant_schools.createIndex({ name: 1 });
db.tenant_sites.createIndex({ name: 1 });
db.assignments.createIndex({ assigneeId: 1 });
db.assignments_mv.createIndex({ displayId: 1, _deleted: 1 });
db.profiles.createIndex({ tenantId: 1, userEmail: 1 });
db.partners.createIndex({ oneSchoolId: 1, _deleted: 1 });
db.partners.createIndex({ tenantId: 1, _deleted: 1 });
```

### Python (`PyMongo`) Script

```python
from pymongo import MongoClient

def setup_indexes(mongo_uri: str):
    client = MongoClient(mongo_uri)
    
    # ExxatNetwork indexes
    exxat = client["ExxatNetwork"]
    exxat.profile_associations.create_index([("userEmail", 1), ("_deleted", 1)])
    exxat.profile_associations.create_index([("tenantId", 1), ("persona", 1), ("active", 1), ("_deleted", 1)])
    exxat.profile_associations.create_index([("oneSchoolId", 1), ("persona", 1), ("active", 1), ("_deleted", 1)])
    
    # Rubix indexes
    rubix = client["Rubix"]
    rubix.assignees.create_index([("userEmail", 1), ("_deleted", 1)])
    rubix.tenant_schools.create_index([("name", 1)])
    rubix.tenant_sites.create_index([("name", 1)])
    rubix.assignments.create_index([("assigneeId", 1)])
rubix.assignments_mv.create_index([("displayId", 1), ("_deleted", 1)])
    rubix.profiles.create_index([("tenantId", 1), ("userEmail", 1)])
    rubix.partners.create_index([("oneSchoolId", 1), ("_deleted", 1)])
    rubix.partners.create_index([("tenantId", 1), ("_deleted", 1)])
    
    print("All indexes created successfully.")
```
